-- Пример входного файла для обфускатора (Lua 5.1 / Roblox-совместимый код).
-- Запуск исходника:      lua5.3 example.lua
-- Обфускация:            python3 obfuscator_ng.py example.lua -o example_obf.lua --layers 3 --test

local function fib(n)
  if n < 2 then return n end
  return fib(n - 1) + fib(n - 2)
end

local t = {}
for i = 1, 10 do t[i] = fib(i) * 2 end
print("sum", table.concat(t, ","))

local s = "hello" .. " " .. "world"
print(s:upper(), #s, string.format("%d-%s", 42, "x"))

local mt = setmetatable({}, {__index = function(_, k) return k .. "!" end})
print(mt.foo, mt.bar)
