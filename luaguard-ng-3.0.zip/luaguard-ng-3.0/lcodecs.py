#!/usr/bin/env python3
"""
LuaGuard NG — text codecs.

Each codec turns ciphertext bytes into printable text and emits the matching Lua
decoder (text -> table of byte numbers).  Alphabets / symbols are randomized per
build, so no two builds share a recognizable encoding.
"""

from __future__ import annotations

import random
import string
from typing import Dict, List, Tuple

PUNCT = ".,:;~^!@#$%&*()[]{}<>?/\\|+-="


class Codec:
    name = "base"

    def __init__(self, rng: random.Random):
        self.rng = rng

    def encode(self, data: bytes) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    def lua_decode(self, nm, raw: str, out_tbl: str) -> str:  # pragma: no cover
        raise NotImplementedError


class HexishCodec(Codec):
    """2 printable symbols per byte, random 16-symbol alphabet."""

    name = "hex"

    def __init__(self, rng: random.Random):
        super().__init__(rng)
        pool = [c for c in (string.ascii_letters + string.digits) if c not in "lI1O0"]
        self.alpha = "".join(rng.sample(pool, 16))

    def encode(self, data: bytes) -> str:
        return "".join(self.alpha[b >> 4] + self.alpha[b & 15] for b in data)

    def lua_decode(self, nm, raw: str, out_tbl: str) -> str:
        AL, M, i, ch, t = nm.n(), nm.n(), nm.n(), nm.n(), nm.n()
        return (f"local {AL}='{self.alpha}' local {M}={{}} "
                f"for {i}=1,#{AL} do {M}[{AL}:sub({i},{i})]={i}-1 end "
                f"local {t}={{}} for {i}=1,#{raw}-1,2 do "
                f"{t}[#{t}+1]=({M}[{raw}:sub({i},{i})] or 0)*16+({M}[{raw}:sub({i}+1,{i}+1)] or 0) end "
                f"{out_tbl}={t} ")


class NumeralsCodec(Codec):
    """Custom 10-symbol numeral system, 3 symbols per byte, junk separators."""

    name = "numerals"

    def __init__(self, rng: random.Random):
        super().__init__(rng)
        pool = [c for c in (string.ascii_letters + string.digits) if c not in "lI1O0"]
        self.digits = "".join(rng.sample(pool, 10))
        self.sep = "".join(rng.sample([c for c in PUNCT], rng.randint(2, 4)))
        self.sep_ratio = rng.uniform(0.1, 0.5)

    def encode(self, data: bytes) -> str:
        out = []
        for b in data:
            out.append(self.digits[b // 100])
            out.append(self.digits[(b // 10) % 10])
            out.append(self.digits[b % 10])
            if self.rng.random() < self.sep_ratio:
                out.append(self.rng.choice(self.sep))
        return "".join(out)

    def lua_decode(self, nm, raw: str, out_tbl: str) -> str:
        D, M, i, ch, acc, cnt, t = (nm.n() for _ in range(7))
        return (f"local {D}='{self.digits}' local {M}={{}} "
                f"for {i}=1,#{D} do {M}[{D}:sub({i},{i})]={i}-1 end "
                f"local {t}={{}} local {acc}=0 local {cnt}=0 "
                f"for {i}=1,#{raw} do {ch}={M}[{raw}:sub({i},{i})] "
                f"if {ch} then {acc}=({acc}*10+{ch})%1000 {cnt}={cnt}+1 "
                f"if {cnt}==3 then {t}[#{t}+1]={acc} {acc}=0 {cnt}=0 end end end "
                f"{out_tbl}={t} ")


class Base64ishCodec(Codec):
    """3 bytes -> 4 symbols from a random 64-symbol alphabet."""

    name = "b64"

    def __init__(self, rng: random.Random):
        super().__init__(rng)
        pool = [c for c in (string.ascii_letters + string.digits + PUNCT) if c not in "'\"\\lI1O0"]
        self.alpha = "".join(rng.sample(pool, 64))
        self.pad = rng.choice([c for c in PUNCT if c not in self.alpha])

    def encode(self, data: bytes) -> str:
        out = []
        for i in range(0, len(data), 3):
            chunk = data[i:i + 3]
            while len(chunk) < 3:
                chunk += b"\x00"
            b1, b2, b3 = chunk
            vals = [b1 >> 2, ((b1 & 3) << 4) | (b2 >> 4), ((b2 & 15) << 2) | (b3 >> 6), b3 & 63]
            out += [self.alpha[v] for v in vals]
        return "".join(out)

    def lua_decode(self, nm, raw: str, out_tbl: str) -> str:
        AL, M, i, c1, c2, c3, c4, t = (nm.n() for _ in range(8))
        return (f"local {AL}='{self.alpha}' local {M}={{}} "
                f"for {i}=1,#{AL} do {M}[{AL}:sub({i},{i})]={i}-1 end "
                f"local {t}={{}} for {i}=1,#{raw}-3,4 do "
                f"{c1}={M}[{raw}:sub({i},{i})] or 0 {c2}={M}[{raw}:sub({i}+1,{i}+1)] or 0 "
                f"{c3}={M}[{raw}:sub({i}+2,{i}+2)] or 0 {c4}={M}[{raw}:sub({i}+3,{i}+3)] or 0 "
                f"{t}[#{t}+1]={c1}*4+math.floor({c2}/16) "
                f"{t}[#{t}+1]=({c2}%16)*16+math.floor({c3}/4) "
                f"{t}[#{t}+1]=({c3}%4)*64+{c4} end {out_tbl}={t} ")


class CardsCodec(Codec):
    """4 tiny tokens per byte (suit letter + rank digit)."""

    name = "cards"

    def __init__(self, rng: random.Random):
        super().__init__(rng)
        suits = rng.sample("SHCD", 4)
        ranks = rng.sample("23456789", 4)  # 4 suits x 4 ranks = 16 states (2 bits)
        self.suits = "".join(suits)
        self.ranks = "".join(ranks)
        self.gap = rng.choice([" ", "|", "-", "."])

    def encode(self, data: bytes) -> str:
        out = []
        for b in data:
            outs = []
            for shift in (6, 4, 2, 0):
                v = (b >> shift) & 3
                outs.append(self.suits[v >> 2] + self.ranks[v & 3])
            out.append(self.gap.join(outs))
        return self.gap.join(out)

    def lua_decode(self, nm, raw: str, out_tbl: str) -> str:
        SU, RA, i, tok, v, acc, sh, t = (nm.n() for _ in range(8))
        gap = " " if self.gap == " " else self.gap
        return (f"local {SU}='{self.suits}' local {RA}='{self.ranks}' "
                f"local {t}={{}} local {acc}=0 local {sh}=3 local {v}=0 "
                f"for {tok} in {raw}:gmatch('[^{gap}]+') do local a={SU}:find({tok}:sub(1,1),1,true) "
                f"local {i}={RA}:find({tok}:sub(2,2),1,true) "
                f"if a and {i} then {v}=((a-1)%4)*4+((({i}-1)%4)) "
                f"{acc}={acc}+{v}*2^(2*{sh}) {sh}={sh}-1 "
                f"if {sh}<0 then {t}[#{t}+1]={acc} {acc}=0 {sh}=3 end end end {out_tbl}={t} ")


class WordsCodec(Codec):
    """One generated word per byte (big, but looks like prose)."""

    name = "words"

    def __init__(self, rng: random.Random):
        super().__init__(rng)
        syll = ["ka", "ro", "mi", "ta", "se", "lu", "no", "ve", "zi", "du", "pa", "re",
                "sha", "ko", "ni", "me", "tu", "gra", "fen", "dor", "sil", "mar", "ke", "to"]
        used = set()
        self.words: List[str] = []
        while len(self.words) < 256:
            w = "".join(rng.choice(syll) for _ in range(rng.randint(2, 3)))
            if w not in used:
                used.add(w)
                self.words.append(w)
        self.sep = rng.choice([" ", ".", "-", "_"])

    def encode(self, data: bytes) -> str:
        return self.sep.join(self.words[b] for b in data)

    def lua_decode(self, nm, raw: str, out_tbl: str) -> str:
        T, i, tok, t = nm.n(), nm.n(), nm.n(), nm.n()
        return (f"local {T}={{{','.join(repr(w).replace(chr(39), chr(34)) for w in self.words)}}} "
                f"local {t}={{}} local {i}=0 "
                f"for {tok} in {raw}:gmatch('[^{self.sep}]+') do {i}={i}+1 "
                f"local h=0 for q=1,#{T} do if {T}[q]=={tok} then h=q-1 break end end "
                f"{t}[{i}]=h end {out_tbl}={t} ")


CODECS = [HexishCodec, NumeralsCodec, Base64ishCodec, CardsCodec, WordsCodec]
CODEC_BY_NAME = {c.name: c for c in CODECS}
