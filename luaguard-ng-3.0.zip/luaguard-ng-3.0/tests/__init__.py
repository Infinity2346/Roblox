"""LuaGuard NG 3.0 — test package (optional; the obfuscator itself needs none of it)."""
