#!/usr/bin/env python3
"""
Раунды самовзлома: последовательные попытки расшифровать собственный вывод LuaGuard NG.

Запуск:  python3 tests/decrypt_rounds.py [script]
Печатает таблицу «что получил взломщик» по каждому раунду.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests import attack as A  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    script = sys.argv[1] if len(sys.argv) > 1 else "t3_roblox.lua"
    path = script if os.path.exists(script) else os.path.join(HERE, "scripts", script)
    src = open(path, encoding="utf-8").read()
    prod = A.build(src, 555, layers=3, guard=True)
    print(f"Цель: {os.path.basename(path)} ({len(src)} байт) -> защищённый файл "
          f"{len(prod)} байт (seed=555, слоёв=3, защиты ВКЛ)\n")

    rounds = [
        ("1. Статический анализ текста", lambda: A.a1_static_scan(prod, src)),
        ("2. Известный открытый текст", lambda: A.a2_known_plaintext(prod, src)),
        ("3. Хук load + loadstring", lambda: A.a3_hook_attack(prod, src)),
        ("4. Хук после удаления debug", lambda: A.a9_stripped_env(src)),
        ("5. Кража локальных через debug-хук", lambda: A.a10_getlocal_thief(src, src, True)),
        ("6. Слежка за string.char/table.concat", lambda: A.a11_wrapped_strings(src, src, True)),
        ("7. Ложный debug.info (обман проверок)", lambda: A.a12_lying_debug(src, src)),
        ("8. Порча файла (1 байт)", lambda: A.a5_tamper(prod, src)),
        ("9. Своё окружение (_ENV) с подменой load", lambda: A.a13_sandbox_getfenv(src, src)),
        ("10. Хук при ВЫКЛЮЧЕННОЙ защите (эталон)", lambda: A.a3_hook_attack(
            A.build(src, 555, layers=3, guard=False), src)),
    ]
    got_plain = 0
    for name, fn in rounds:
        try:
            res = fn()
        except Exception as e:  # noqa: BLE001
            print(f"{name:44s} ошибка теста: {e}")
            continue
        recovered = bool(res.get("payload_recovered"))
        if recovered:
            got_plain += 1
        what = "ИСХОДНИК ПОЛУЧЕН" if recovered else "исходник не получен"
        extra = {k: v for k, v in res.items() if k not in ("payload_recovered",)}
        print(f"{name:44s} {what:22s} {extra}")
    print(f"\nИтог: расшифровать удалось в {got_plain} из {len(rounds)} раундов "
          f"(ожидаемо — только там, где защита выключена вручную).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
