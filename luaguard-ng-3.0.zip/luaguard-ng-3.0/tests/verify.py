#!/usr/bin/env python3
"""
Correctness harness for LuaGuard NG.

For every test program and several seeds:
  1. build an obfuscated file (guards ON)  -> run it in a clean Lua VM -> compare output
     with the original program.
  2. build the same seed with guards OFF  -> run it with a capturing loader -> the captured
     chunk must be byte-identical to the original source (proves the emitted Lua decrypts
     exactly, layer by layer).
  3. run the production build 3x -> outputs must be stable.
Environments: "plain" (Lua 5.5, no bit32/game/loadstring) and "roblox" (game + typeof +
bit32 + loadstring + getfenv/setfenv shims).
"""
from __future__ import annotations

import os
import sys
from typing import Dict, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import lupa  # noqa: E402

from obfuscator_ng import LuaGuardNG  # noqa: E402

# The Lua implementation used for the checks.  lupa ships several, which lets the same build
# be verified on real Lua 5.1/5.2/5.3/5.4/5.5 and LuaJIT 2.0/2.1 userdata.
RUNTIME = lupa
RUNTIME_NAMES = ["lua51", "lua52", "lua53", "lua54", "lua55", "luajit20", "luajit21"]

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(HERE, "scripts")

PRELUDE_COMMON = r"""
_out = {}
function print(...)
  local t = {}
  for i = 1, select('#', ...) do t[i] = tostring(select(i, ...)) end
  _out[#_out + 1] = table.concat(t, '\t')
end
"""

PRELUDE_ROBLOX = PRELUDE_COMMON + r"""
game = { GetService = function(self, n) return {Name = n} end,
         HttpGet = function(self, u) return 'print("REMOTE_STUB_OK")' end }
typeof = function(v) return type(v) end
-- executors expose loadstring; in 5.2+ alias it to the native string loader (never a
-- Lua wrapper: that would legitimately trip the anti-hook check)
if not rawget(_G, 'loadstring') then loadstring = load end
if not rawget(_G, 'getfenv') then getfenv = function() return _G end end
if not rawget(_G, 'setfenv') then setfenv = function(f, e) return f end end
task = { spawn = function(f) pcall(f) end, wait = function() end }
"""

PRELUDE_NOLOAD = PRELUDE_COMMON + r"""
-- executor-style environment: `load` removed, only loadstring exists.
-- loadstring must stay the SAME native function (executors expose a C builtin),
-- so we alias it instead of wrapping it.
if not rawget(_G, 'loadstring') then loadstring = load end
load = nil
"""

HOOK_LOADER = r"""
-- the classic deobfuscation hook: capture every source string handed to the loader.
-- A real tool hooks BOTH names (`load` and `loadstring`), so the audit does the same.
_real_load = load
_real_ls = rawget(_G, 'loadstring')
_captured = {}
local function call_real(src, name, mode)
  if type(src) == 'string' and _real_ls then return _real_ls(src, name, mode) end
  return _real_load(src, name, mode)
end
local function hook(src, name, mode, env)
  if type(src) == 'string' then _captured[#_captured + 1] = src end
  if env == nil then return call_real(src, name, mode) end
  return _real_ls and _real_ls(src, name, mode, env) or _real_load(src, name, mode, env)
end
load = hook
if _real_ls then loadstring = hook end
"""


import re as _re

def _norm(x):
    """Normalize chunk-name noise inside Lua error messages."""
    if isinstance(x, str):
        x = _re.sub(r"\[string \"[^\"]*\"\]", "[chunk]", x)
        x = _re.sub(r"\((load|loadstring)\)", "[chunk]", x)   # loader decides the chunk name
        return x
    return x


def _eval_out(rt) -> List[str]:
    n = rt.eval("#_out")
    return [rt.eval(f"_out[{i}]") for i in range(1, n + 1)]


PRELUDE = {"plain": PRELUDE_COMMON, "roblox": PRELUDE_ROBLOX, "noload": PRELUDE_NOLOAD}


def run_program(code: str, env: str = "plain") -> Tuple[bool, object]:
    rt = RUNTIME.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE[env])
    try:
        rt.execute(code)
        return True, _eval_out(rt)
    except Exception as e:  # noqa: BLE001
        return False, _norm(str(e).splitlines()[0])


def run_capture(code: str, env: str = "plain") -> Tuple[bool, List[str], str]:
    rt = RUNTIME.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE[env])
    if env == "noload":
        rt.execute("load = loadstring")      # the capture hook then replaces both names
    rt.execute(HOOK_LOADER)
    try:
        rt.execute(code)
    except Exception as e:  # noqa: BLE001
        return False, [], str(e).splitlines()[0]
    n = rt.eval("#_captured")
    caps = [rt.eval(f"_captured[{i}]") for i in range(1, n + 1)]
    return True, caps, ""


def build(src: str, seed: int, layers: int, guard: bool = True, decoys: int = 2) -> str:
    return LuaGuardNG(src, layers=layers, seed=seed, guard=guard, decoys=decoys).build()


def run_matrix() -> int:
    """Same build, every Lua implementation lupa provides: the file must behave identically."""
    import importlib
    global RUNTIME
    programs = sorted(f for f in os.listdir(SCRIPTS) if f.endswith(".lua"))
    fails: List[str] = []
    checks = 0
    for name in RUNTIME_NAMES:
        RUNTIME = importlib.import_module(f"lupa.{name}")
        for prog in programs:
            src = open(os.path.join(SCRIPTS, prog), encoding="utf-8").read()
            for env in ("plain", "roblox", "noload"):
                ok_ref, ref = run_program(src, env)
                if not ok_ref:
                    continue
                for build_no, (seed, layers) in enumerate(((5, 1), (6, 2), (7, 3))):
                    checks += 1
                    label = f"{name} {prog} env={env} seed={seed} layers={layers}"
                    try:
                        obf = build(src, seed, layers, guard=True)
                    except Exception as e:  # noqa: BLE001
                        fails.append(f"BUILD {label}: {e}")
                        continue
                    ok, out = run_program(obf, env)
                    if not ok:
                        fails.append(f"RUN   {label}: {out}")
                    elif [_norm(v) for v in out] != [_norm(v) for v in ref]:
                        fails.append(f"OUT   {label}: {list(out)} != {list(ref)}")
                    if build_no == 2:      # exact decryption, once per (runtime, program, env)
                        obf_nog = build(src, seed, layers, guard=False, decoys=0)
                        okc, caps, err = run_capture(obf_nog, env)
                        if not okc or src not in caps:
                            fails.append(f"CAP   {label}: {err or 'payload not recovered'}")
    print(f"runtime matrix checks: {checks}, failures: {len(fails)}")
    for f in fails[:40]:
        print("  -", f)
    return 1 if fails else 0


def main() -> int:
    if "--matrix" in sys.argv:
        return run_matrix()
    programs = sorted(f for f in os.listdir(SCRIPTS) if f.endswith(".lua"))
    seeds = [1, 7, 424242]
    layers_list = [2, 3, 4]
    fails: List[str] = []
    checks = 0

    for prog in programs:
        src = open(os.path.join(SCRIPTS, prog), encoding="utf-8").read()
        for env in ("plain", "roblox", "noload"):
            ok_ref, ref = run_program(src, env)
            if not ok_ref:
                print(f"SKIP {prog} ({env}): original does not run: {ref}")
                continue
            for seed in seeds:
                for layers in layers_list:
                    checks += 1
                    label = f"{prog} env={env} seed={seed} layers={layers}"
                    try:
                        obf = build(src, seed, layers, guard=True)
                    except Exception as e:  # noqa: BLE001
                        fails.append(f"BUILD {label}: {e}")
                        continue
                    # 1. behaviour
                    ok, out = run_program(obf, env)
                    if not ok:
                        fails.append(f"RUN  {label}: {out}")
                        continue
                    if [_norm(v) for v in out] != [_norm(v) for v in ref]:
                        fails.append(f"OUT  {label}: {list(out)} != {list(ref)}")
                        continue
                    # 2. stability (3 runs, different runtime entropy)
                    for _ in range(2):
                        ok2, out2 = run_program(obf, env)
                        if not ok2 or [_norm(v) for v in out2] != [_norm(v) for v in ref]:
                            fails.append(f"STAB {label}: run2={out2 if ok2 else out2}")
                            break
                    # 3. exact decryption (guards OFF + capturing loader)
                    obf_nog = build(src, seed, layers, guard=False, decoys=0)
                    okc, caps, err = run_capture(obf_nog, env)
                    if not okc:
                        fails.append(f"CAP  {label}: {err}")
                    elif src not in caps:
                        fails.append(f"CAP  {label}: payload not recovered exactly "
                                     f"(captured {len(caps)} chunks, sizes {[len(c) for c in caps][:8]})")

    print(f"checks: {checks}, failures: {len(fails)}")
    for f in fails[:40]:
        print("  -", f)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
