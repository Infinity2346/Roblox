"""Cross-runtime gate: does the obfuscated output still WORK on every Lua we can reach?

For each of the 7 interpreters shipped with lupa (Lua 5.1, 5.2, 5.3, 5.4, 5.5, LuaJIT 2.0,
LuaJIT 2.1) we run the *guardless* build of every test script and compare its stdout with
the stdout of the plain-source run (byte-exact semantics).  The guarded build must never
crash either: in an environment without the roblox markers it is allowed to run a decoy
program, but it must be valid Lua everywhere.

Run:  timeout 900 python3 -u tests/runtimes.py
"""
from __future__ import annotations

import os
import sys
import traceback
from typing import List, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from obfuscator_ng import DECOYS, LuaGuardNG  # noqa: E402

RUNTIMES = ["lua51", "lua52", "lua53", "lua54", "lua55", "luajit20", "luajit21"]
HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = sorted(f for f in os.listdir(os.path.join(HERE, "scripts")) if f.endswith(".lua"))


def _runtime(name: str):
    mod = __import__("lupa." + name, fromlist=["LuaRuntime"])
    return mod.LuaRuntime()


def _run(rt, code: str, setup: str = "") -> Tuple[bool, object]:
    rt.globals().CODE = code
    rt.execute("OUT = {} _ERR = ''")
    if setup:
        rt.execute(setup)
    try:
        rt.execute("local f, e = (loadstring or load)(CODE) if not f then "
                   "_ERR = 'load: '..tostring(e) "
                   "else local ok, err = pcall(f) if not ok then _ERR = tostring(err) end end")
    except Exception as exc:                                    # pragma: no cover
        return False, f"python-side: {exc!r}"
    err = rt.globals()._ERR
    out = []
    try:
        n = int(rt.eval("#OUT"))
        out = [str(rt.eval(f"OUT[{i}]")) for i in range(1, n + 1)]
    except Exception:                                           # pragma: no cover
        pass
    return (err in (None, "")), (out if not err else f"ERR {err}")


PRELUDE = ("OUT = _G.OUT or {} function print(...) local a = {...} "
           "for i = 1, #a do a[i] = tostring(a[i]) end "
           "OUT[#OUT+1] = table.concat(a, '\\t') end ")


def main() -> int:
    srcs = {}
    for f in SCRIPTS:
        with open(os.path.join(HERE, "scripts", f), encoding="utf-8") as fh:
            srcs[f] = fh.read()

    total = ok_n = 0
    decoy_n = 0
    decoy_outs = set()
    for rtname in RUNTIMES:
        _rt = _runtime(rtname)
        for _d in DECOYS:
            _ok, _out = _run(_rt, _d, PRELUDE)
            if _ok:
                decoy_outs.add(tuple(_out))
        rt = _runtime(rtname)
        ver = rt.eval("_VERSION") + (" +" + rt.eval("tostring(jit and jit.version or '')")
                                     if rt.eval("jit ~= nil") else "")
        line = []
        for f, src in srcs.items():
            for seed in (5, 77):
                # 1) semantics of the payload itself (guardless build)
                built = LuaGuardNG(src, layers=3, seed=seed, guard=False).build()
                rt2 = _runtime(rtname)
                rt2.globals().CODE = src
                ref_ok, ref = _run(rt2, src, PRELUDE)
                rt3 = _runtime(rtname)
                got_ok, got = _run(rt3, built, PRELUDE)
                total += 1
                if ref == got:
                    ok_n += 1
                else:
                    print(f"  - SEM  {rtname} {f} seed={seed}: {got!r} != {ref!r}")
                # 2) the guarded build must behave like the payload (or deliberately run a
                #    decoy program), and must never produce a *new* failure mode
                guarded = LuaGuardNG(src, layers=3, seed=seed, guard=True).build()
                g_ok, g_out = _run(_runtime(rtname), guarded, PRELUDE)
                total += 1
                if g_out == ref:
                    ok_n += 1
                elif tuple(g_out) in decoy_outs:
                    ok_n += 1
                    decoy_n += 1
                elif not ref_ok and not g_ok:
                    ok_n += 1                      # payload itself cannot run here (e.g. t3)
                elif not ref_ok and g_ok and tuple(g_out) in decoy_outs:
                    ok_n += 1
                else:
                    print(f"  - GUARD {rtname} {f} seed={seed}: {g_out!r}")
        print(f"{rtname:9s} {ver[:28]:30s} done")
    print(f"\ncross-runtime gate: {ok_n}/{total} passed "
          f"({decoy_n} guarded runs chose a decoy program, as designed outside roblox)")
    return 0 if ok_n == total else 1


if __name__ == "__main__":
    sys.exit(main())
