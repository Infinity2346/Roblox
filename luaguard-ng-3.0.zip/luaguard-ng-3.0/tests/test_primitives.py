#!/usr/bin/env python3
"""Round-trip proof: every cipher x codec combination decodes correctly in a real Lua VM."""
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import lupa  # noqa: E402

from core import CIPHERS, Namer, frame  # noqa: E402
from lcodecs import CODECS  # noqa: E402

BARE = r"""
_out = {}
function print(...)
  local t = {}
  for i = 1, select('#', ...) do t[i] = tostring(select(i, ...)) end
  _out[#_out + 1] = table.concat(t, '\t')
end
"""


def build_case(ciph_cls, codec_cls, seed, payload_len, pad16=True):
    rng = random.Random(seed)
    nm = Namer(rng)
    payload = ("-- payload\n" + "".join(
        random.Random(seed + 1).choice("abcdefghijklmnopqrstuvwxyz (){},=") for _ in range(payload_len))
    ).encode()
    cipher = ciph_cls(rng)
    ct = cipher.encrypt(frame(payload))
    if pad16 and len(ct) % 16:
        ct = ct + bytes(16 - len(ct) % 16)
    codec = codec_cls(rng)
    raw = codec.encode(ct)
    prologue, env = cipher.lua_material(nm)
    body = [
        prologue,
        f"local RAW={json.dumps(raw)} ",
        "local B " + codec.lua_decode(nm, "RAW", "B"),
        "local P " + cipher.lua_decode(nm, "B", "P", env),
        "local n=P[1]*16777216+P[2]*65536+P[3]*256+P[4] "
        "local t={} for i=1,n do t[i]=string.char(P[i+4]) end local SRC=table.concat(t)",
        "print(n, #SRC, SRC==EXPECTED and 'MATCH' or 'DIFF')",
    ]
    lua = BARE + f"local EXPECTED={json.dumps(payload.decode())}\n" + "\n".join(body)
    return lua, payload


def run(lua_src):
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(lua_src)
    n = rt.eval("#_out")
    return [rt.eval(f"_out[{i}]") for i in range(1, n + 1)]


def main():
    fails = 0
    total = 0
    for ci, ciph_cls in enumerate(CIPHERS):
        for di, codec_cls in enumerate(CODECS):
            for payload_len in (0, 1, 15, 16, 17, 63, 256, 999):
                for seed in (1, 2, 3):
                    total += 1
                    lua, payload = build_case(ciph_cls, codec_cls, seed * 1000 + payload_len, payload_len)
                    try:
                        out = run(lua)
                    except Exception as e:  # noqa: BLE001
                        print(f"FAIL(crash) {ciph_cls.shape}/{codec_cls.name} len={payload_len} seed={seed}: {e}")
                        if os.environ.get("LG_DEBUG"):
                            print("---- generated Lua ----")
                            print(lua[:6000])
                        fails += 1
                        continue
                    line = out[-1]
                    if not line.endswith("MATCH"):
                        print(f"FAIL {ciph_cls.shape}/{codec_cls.name} len={payload_len} seed={seed}: {line}")
                        fails += 1
    print(f"\nprimitive round-trip: {total - fails}/{total} passed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
