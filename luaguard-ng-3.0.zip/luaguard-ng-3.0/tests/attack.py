#!/usr/bin/env python3
"""
Attack suite for LuaGuard NG — "can I still deobfuscate it?" measured, not asserted.

A1  static scan        : plaintext markers / API names / key tables in the output
A2  known-plaintext    : are distinctive strings of the original script recoverable statically?
A3  hook attack (ON)   : the classic 15-line loadstring hook, with guards enabled
A4  hook attack (OFF)  : same, guards disabled (documented limit of any source-level tool)
A5  tamper attack      : flip one blob byte -> must not run the payload, must not crash loudly
A6  polymorphism       : 5 builds -> shared substrings; same seed -> identical file
A7  structural attack  : does one decoder technique fit all layers?
A8  overhead           : size ratio + runtime cost
A9  stripped debug     : hook attack after `debug = nil` (environment sabotage)
A10 debug.getlocal thief: active debug hook that reads our locals while running
A11 wrapped string     : sandbox that replaces string.char/table.concat with Lua loggers
A12 lying debug        : environment that fakes debug.info (documented boundary)
"""
from __future__ import annotations

import difflib
import os
import random
import re
import statistics
import sys
import time
from typing import Dict, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import lupa  # noqa: E402

from obfuscator_ng import LuaGuardNG  # noqa: E402
from tests.verify import PRELUDE_COMMON, PRELUDE_ROBLOX, run_program  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(HERE, "scripts")
HOOK_SRC = r"""
_hex = function(s) local t={} for i=1,#s do t[i]=string.format('%02x', s:byte(i)) end return table.concat(t) end
_cap = {}
_real_ls = rawget(_G, 'loadstring')
_real_load = rawget(_G, 'load')
local function call_real(src, name, mode)
  if type(src) == 'string' and _real_ls then return _real_ls(src, name, mode) end
  return _real_load(src, name, mode)
end
local function hook(src, name, mode, env)
  if type(src) == 'string' then _cap[#_cap + 1] = _hex(src) end
  if env == nil then return call_real(src, name, mode) end
  return _real_ls and _real_ls(src, name, mode, env) or _real_load(src, name, mode, env)
end
load = hook
if _real_ls then loadstring = hook end
"""

PAYLOAD_MARKERS = ["loadstring", "HttpGet", "GetService", "DexPlusPlus", "print(", "return"]
API_NAMES = ["loadstring", "setfenv", "getfenv", "rawget", "string.char", "table.concat",
             "function", "local ", "print"]


# ---------------------------------------------------------------- helpers
def build(src: str, seed: int, layers: int = 3, guard: bool = True, decoys: int = 2) -> str:
    return LuaGuardNG(src, layers=layers, seed=seed, guard=guard, decoys=decoys).build()


def capture_with_hook(code: str, env: str = "roblox") -> Tuple[bool, List[bytes], str]:
    """Run `code` in a VM whose `load` is replaced by a Lua-level capture hook."""
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX if env == "roblox" else PRELUDE_COMMON)
    rt.execute(HOOK_SRC)
    try:
        rt.execute(code)
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    n = rt.eval("#_cap")
    caps = [bytes.fromhex(rt.eval(f"_cap[{i}]")) for i in range(1, n + 1)]
    return True, caps, err


def lcs_len(a: str, b: str) -> int:
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    m = sm.find_longest_match(0, len(a), 0, len(b))
    return m.size


# ---------------------------------------------------------------- attacks
def a1_static_scan(code: str, payload: str) -> Dict[str, object]:
    hits_api = {n: code.count(n) for n in API_NAMES if code.count(n)}
    hits_marker = {m: code.count(m) for m in PAYLOAD_MARKERS if code.count(m)}
    # does any long slice of the payload appear verbatim in the file?
    snippets = [payload[i:i + 24] for i in range(0, max(0, len(payload) - 24), 40)]
    leaked = sum(1 for s in snippets if s.strip() and s in code)
    return {"api_hits": hits_api, "marker_hits": hits_marker,
            "payload_snippets_leaked": leaked, "snippets_checked": len(snippets)}


def a2_known_plaintext(code: str, payload: str) -> Dict[str, object]:
    """Try to find the payload inside every quoted literal of the file, after common
    single-step decodings (i.e. the 'v1 breaker' approach)."""
    lits = re.findall(r"'([^']{8,})'", code) + re.findall(r'"([^"]{8,})"', code)
    blob = "".join(lits)
    try:
        b64 = __import__("base64").b64decode(blob, validate=False)
    except Exception:  # noqa: BLE001
        b64 = b""
    found = any(k in blob for k in ("loadstring", "HttpGet")) or b"loadstring" in b64
    return {"literals": len(lits), "literal_bytes": len(blob), "recovered": found}


def a3_hook_attack(code: str, payload: str, env: str = "roblox") -> Dict[str, object]:
    ok, caps, err = capture_with_hook(code, env)
    exact = any(c == payload.encode() for c in caps)
    return {"chunks": len(caps), "payload_recovered": exact,
            "chunk_sizes": sorted(len(c) for c in caps)[:8], "err": err[:80]}


def a5_tamper(code: str, payload: str) -> Dict[str, object]:
    """Flip single bytes inside the ciphertext blob (the data the file is built from).

    Two honest measurements:
      * guard ON  -> the shipped file must stay silent: no output, no visible error;
      * guard OFF -> there is no decoy to fall back on, so a flip that lands in real
        ciphertext must NOT execute the payload.  A few flips can land in the random junk
        fragments that live in the same blob; those are counted separately ("padding").
    """
    def long_literals(text: str) -> List[Tuple[int, int]]:
        """Real string-literal spans (>=40 bytes) found with a Lua-aware scanner."""
        out, i, n = [], 0, len(text)
        while i < n:
            ch = text[i]
            if ch in "'\"":
                j, start = i + 1, i + 1
                while j < n:
                    if text[j] == "\\":
                        j += 2
                        continue
                    if text[j] == ch:
                        break
                    j += 1
                if j - start >= 40:
                    out.append((start, j))
                i = j + 1
                continue
            if text.startswith("--", i):
                k = text.find("\n", i)
                i = n if k < 0 else k
                continue
            i += 1
        return out

    def flip(text: str, pos: int) -> str:
        ch = text[pos]
        return text[:pos] + ("9" if ch != "9" else "8") + text[pos + 1:]

    res: Dict[str, object] = {}
    spans = long_literals(code)
    rng = random.Random(4242)
    if spans:
        picks = [rng.randrange(a, b) for a, b in rng.choices(spans, k=8)]
        silent = errors = ran = 0
        for pos in picks:
            ok, out = run_program(flip(code, pos), "roblox")
            if not ok:
                errors += 1
            elif len(out) == 0:
                silent += 1
            else:
                ran += 1
        res.update({"guard_on_flips": len(picks), "guard_on_silent": silent,
                    "guard_on_errors": errors, "guard_on_payload_still_ran": ran})

    nog = build(payload, 555, layers=3, guard=False, decoys=0)
    spans2 = long_literals(nog)
    picks2 = [rng.randrange(a, b) for a, b in rng.choices(spans2, k=8)] if spans2 else []
    killed = ran2 = errored = 0
    for pos in picks2:
        ok, out = run_program(flip(nog, pos), "roblox")
        if not ok:
            errored += 1
        elif len(out) == 0:
            killed += 1
        else:
            ran2 += 1
    res.update({"guardless_flips": len(picks2), "guardless_killed": killed,
                "guardless_still_ran": ran2, "guardless_errors": errored})
    return res


def a6_polymorphism(src: str, n: int = 5) -> Dict[str, object]:
    outs = [build(src, 1000 + i, layers=3) for i in range(n)]
    ratios = []
    for i in range(n - 1):
        ratios.append(lcs_len(outs[i], outs[i + 1]) / max(len(outs[i]), len(outs[i + 1])))
    same_seed = build(src, 777, layers=3) == build(src, 777, layers=3)
    return {"lcs_ratio_max": round(max(ratios), 4), "lcs_ratio_mean": round(statistics.mean(ratios), 4),
            "same_seed_reproducible": same_seed, "sizes": sorted(len(o) for o in outs)}


def a7_structural(src: str, n: int = 6) -> Dict[str, object]:
    g = LuaGuardNG(src, layers=3, seed=4242)
    g.build()
    shapes = [a for a, _ in g.methods]
    return {"layer_ciphers": shapes, "distinct_ciphers": len(set(shapes))}


def a8_overhead(src: str) -> Dict[str, object]:
    plain_t = []
    for _ in range(3):
        t0 = time.perf_counter()
        run_program(src, "roblox")
        plain_t.append(time.perf_counter() - t0)
    obf = build(src, 31337, layers=3)
    obf_t = []
    for _ in range(3):
        t0 = time.perf_counter()
        run_program(obf, "roblox")
        obf_t.append(time.perf_counter() - t0)
    return {"size_ratio": round(len(obf) / len(src), 1),
            "plain_ms": round(statistics.median(plain_t) * 1000, 2),
            "obf_ms": round(statistics.median(obf_t) * 1000, 2)}


def a10_getlocal_thief(code: str, payload: str, guard: bool) -> Dict[str, object]:
    """Attacker installs a debug hook and reads the locals of the running chunk every line.

    Strongest in-process attack that does not patch the file: the loader still looks native,
    so only the *hook* betrays the attacker - which is exactly what the runtime salt detects.
    """
    prod = build(payload, 555, layers=3, guard=guard)
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX)
    rt.execute("""
    _seen, _total = {}, 0
    local _tc = table.concat
    _hex = function(s) local t={} for i=1,#s do t[i]=('%02x'):format(s:byte(i)) end return _tc(t) end
    local _scan = function(lvl)
      for i = 1, 60 do
        local n, v = debug.getlocal(lvl, i)
        if n == nil then break end
        -- cheap heuristic a real thief would use: a long, code-looking string
        if type(v) == 'string' and #v > 64 and #v < 4096 and v:find('local', 1, true) then
          _total = _total + 1
          _seen[(_total % 3000) + 1] = v          -- ring buffer: keep the newest ones
        end
      end
    end
    debug.sethook(function() for lvl = 1, 6 do pcall(_scan, lvl) end end, "l", 0)
    """)
    try:
        rt.execute(prod)
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    n = int(rt.eval("#_seen"))
    blob = "|".join(rt.eval("_hex(_seen[%d])" % i) for i in range(1, n + 1) if rt.eval(f"_seen[{i}]") is not None)
    return {"locals_seen": int(rt.eval("_total")),
            "payload_recovered": payload.encode().hex() in blob,
            "payload_snippet_found": payload[:40].encode().hex() in blob, "err": err[:60]}


def _wrapped_core_prelude() -> str:
    """Sandbox that keeps a native loader but replaces string.char/table.concat with Lua loggers."""
    return """
    _log = {}
    local _tc, _cc = table.concat, string.char
    local _hex = function(s) local t={} for i=1,#s do t[i]=('%02x'):format(s:byte(i)) end return _tc(t) end
    string.char = function(...) local r=_cc(...) if #_log<200000 then _log[#_log+1]=_hex(r) end return r end
    table.concat = function(t, ...) local r=_tc(t, ...) if #_log<200000 then _log[#_log+1]=_hex(r) end return r end
    """


def _log_blob(rt) -> str:
    n = int(rt.eval("#_log"))
    return "|".join(rt.eval(f"_log[{i}]") for i in range(1, min(n, 200000) + 1))


def a11_wrapped_strings(code: str, payload: str, guard: bool) -> Dict[str, object]:
    """Sandbox logging every byte the decoder builds (native loader preserved)."""
    prod = build(payload, 555, layers=3, guard=guard)
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX)
    rt.execute(_wrapped_core_prelude())
    try:
        rt.execute(prod)
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    blob, ph = _log_blob(rt), payload.encode().hex()
    return {"chars_logged": int(rt.eval("#_log")), "payload_recovered": ph in blob,
            "payload_snippet_found": payload[:40].encode().hex() in blob, "err": err[:60]}


def a12_lying_debug(code: str, payload: str) -> Dict[str, object]:
    """Attacker wraps core functions *and* makes debug.info/getinfo report 'C' for Lua functions.

    Documented boundary: full control over the introspection API defeats function-identity
    checks, exactly like full control over the interpreter itself.
    """
    prod = build(payload, 555, layers=3, guard=True)
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX)
    rt.execute(_wrapped_core_prelude())
    rt.execute("""
    local _ri, _rg = debug.info, debug.getinfo
    if _ri then debug.info = function(f, what, ...)
      local r=_ri(f, what, ...) if type(r)=='table' and r.what=='Lua' then r.what='C' end return r end end
    if _rg then debug.getinfo = function(f, what, ...)
      local r=_rg(f, what, ...) if type(r)=='table' and r.what=='Lua' then r.what='C' end return r end end
    """)
    try:
        rt.execute(prod)
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    blob, ph = _log_blob(rt), payload.encode().hex()
    return {"payload_recovered": ph in blob, "err": err[:60]}


def a13_sandbox_getfenv(code: str, payload: str) -> Dict[str, object]:
    """Attacker runs the file with a custom environment (_ENV sandbox) and hooks load in it."""
    prod = build(payload, 555, layers=3, guard=True)
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX)
    rt.globals().FILE = prod
    rt.execute("""
    _cap = {}
    _env = setmetatable({}, {__index = _G})
    _env.load = function(src, ...) if type(src)=='string' then _cap[#_cap+1]=src end return load(src, ...) end
    _chunk = load(FILE, 'sbx', 't', _env)
    """)
    try:
        rt.execute("pcall(_chunk)")
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    n = int(rt.eval("#_cap"))
    caps = [rt.eval(f"#_cap[{i}]") for i in range(1, n + 1)]
    return {"chunks": n, "chunk_sizes": caps[:8],
            "payload_recovered": any(c == len(payload) for c in caps), "err": err[:60]}


def a14_debugless_env(src: str) -> Dict[str, object]:
    """Honest boundary probe: strip *every* introspection channel AND wrap the loader.

    Removing `debug`, `string.dump`, `game` and `typeof` leaves the runtime salt with nothing
    to react to (`RS = 0`), exactly like a fully controlled interpreter would - and a custom
    environment that no longer provides `game` cannot run a roblox payload either.  This is
    the documented edge of what pure-Lua obfuscation can do.
    """
    prod = build(src, 9091, layers=3, guard=True)
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX)
    rt.execute("""
    _cap = {}
    local _rl = load
    local _hook = function(s, ...) if type(s) == 'string' then _cap[#_cap+1] = s end
      return _rl(s, ...) end
    load, loadstring = _hook, _hook
    debug, string.dump, game, typeof = nil, nil, nil, nil
    """)
    try:
        rt.execute(prod)
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    n = int(rt.eval("#_cap"))
    caps = [rt.eval(f"_cap[{i}]") for i in range(1, n + 1)]
    return {"chunks": n, "chunk_sizes": sorted(len(c) for c in caps)[:6],
            "payload_recovered": any(c == src for c in caps), "err": err[:60]}


def main() -> int:
    name = sys.argv[1] if len(sys.argv) > 1 else "t3_roblox.lua"
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    prod = build(src, 555, layers=3, guard=True)          # what the user would ship
    noaudit = build(src, 555, layers=3, guard=False, decoys=0)

    print(f"payload: {name} ({len(src)} bytes) -> shipped file: {len(prod)} bytes\n")
    print("A1 static scan        :", a1_static_scan(prod, src))
    print("A2 known-plaintext    :", a2_known_plaintext(prod, src))
    print("A3 hook attack (ON)   :", a3_hook_attack(prod, src))
    print("A4 hook attack (OFF)  :", a3_hook_attack(noaudit, src))
    print("A5 tamper attack      :", a5_tamper(prod, src))
    print("A6 polymorphism       :", a6_polymorphism(src))
    print("A7 structural attack  :", a7_structural(src))
    print("A8 overhead           :", a8_overhead(src))
    print("A9 stripped-debug hook :", a9_stripped_env(src))
    print("A10 getlocal thief ON  :", a10_getlocal_thief(src, src, guard=True))
    print("A10 getlocal thief OFF :", a10_getlocal_thief(src, src, guard=False))
    print("A11 wrapped strings ON :", a11_wrapped_strings(src, src, guard=True))
    print("A12 lying debug        :", a12_lying_debug(src, src))
    print("A13 sandboxed env      :", a13_sandbox_getfenv(src, src))
    print("A14 no-introspection   :", a14_debugless_env(src))
    return 0




def a9_stripped_env(src: str) -> Dict[str, object]:
    """Attack: deobfuscator removes `debug` from the environment to silence hook detection."""
    prod = build(src, 9091, layers=3, guard=True)
    rt = lupa.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(PRELUDE_ROBLOX)
    rt.execute(HOOK_SRC)
    rt.execute("debug = nil       -- <-- the attack")
    try:
        rt.execute(prod)
        err = ""
    except Exception as e:  # noqa: BLE001
        err = str(e).splitlines()[0]
    n = rt.eval("#_cap")
    caps = [bytes.fromhex(rt.eval(f"_cap[{i}]")) for i in range(1, n + 1)]
    return {"payload_recovered": any(c == src.encode() for c in caps),
            "chunks": [len(c) for c in caps][:6], "err": err[:60]}




if __name__ == "__main__":
    sys.exit(main())
