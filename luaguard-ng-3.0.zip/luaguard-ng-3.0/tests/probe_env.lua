-- environment probe: reports what the runtime salt would see, one check per line
local D = rawget(_G, 'debug')
local info = nil
if type(D) == 'table' then
  if type(D.info) == 'function' then
    info = function(f)
      local o, r = pcall(D.info, f, 's')
      if o and type(r) == 'table' then return r end
    end
  elseif type(D.getinfo) == 'function' then
    info = function(f)
      local o, r = pcall(D.getinfo, f, 'S')
      if o and type(r) == 'table' then return r end
    end
  end
end

local L = rawget(_G, 'loadstring') or rawget(_G, 'load')
local function what(f)
  local r = info and info(f)
  return tostring(r and r.what)
end
local res = {}
res[#res + 1] = 'debug=' .. type(D) .. ' info_fn=' .. tostring(info ~= nil)
res[#res + 1] = 'loader=' .. type(L) .. ' what=' .. what(L)
res[#res + 1] = 'stringchar=' .. what(string.char)
res[#res + 1] = 'tableconcat=' .. what(table.concat)
res[#res + 1] = 'mathfloor=' .. what(math.floor)
res[#res + 1] = 'stringdump=' .. what(string.dump)
res[#res + 1] = 'gethook=' .. type(D and D.gethook)
if D and type(D.gethook) == 'function' then
  local ok, hk = pcall(D.gethook)
  res[#res + 1] = 'active_hook=' .. tostring(ok and hk ~= nil)
end
res[#res + 1] = 'game=' .. type(rawget(_G, 'game')) .. ' typeof=' .. type(rawget(_G, 'typeof'))
res[#res + 1] = 'stringdump_ok=' .. tostring(pcall(string.dump, string.char))
R = table.concat(res, '\n')

-- guard hard-check rehearsal against the *loader actually chosen*
local LL = rawget(_G, 'loadstring') or rawget(_G, 'load')
local out = {}
local a, b = pcall(LL, ')')
out[#out+1] = 'load(")") ok=' .. tostring(a) .. ' type2=' .. type(b)
out[#out+1] = 'load("return 1")=' .. type(LL('return 1'))
out[#out+1] = 'load("")=' .. type(LL(''))
out[#out+1] = 'load("local a=1")=' .. type(LL('local a=1'))
local okh, hk = pcall(D.gethook)
out[#out+1] = 'gethook ok=' .. tostring(okh) .. ' nonnil=' .. tostring(hk ~= nil) .. ' type=' .. type(hk)
out[#out+1] = 'chk2(load)=' .. tostring(pcall(string.dump, LL))
R2 = table.concat(out, '\n')
