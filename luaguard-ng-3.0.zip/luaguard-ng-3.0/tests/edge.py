#!/usr/bin/env python3
"""
Edge-case gate: unusual but legitimate Lua sources must survive obfuscation.

Covers the pitfalls that break hand-written obfuscators: CRLF, UTF-8, BOM, shebang,
long strings with `--` inside, escaped quotes, NUL bytes, hexadecimal/exponent/`//`
numbers, empty and comment-only files.  The obfuscated file must produce the same
output as the (normalised) original on every Lua implementation lupa ships.
"""
from __future__ import annotations

import importlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import lupa  # noqa: E402

import tests.verify as V  # noqa: E402
from obfuscator_ng import LuaGuardNG  # noqa: E402

CASES = [
    ("shebang", "#!/usr/bin/lua\nprint('shebang ok')\n", "print('shebang ok')\n"),
    ("bom", "\ufeffprint('bom ok')\n", "print('bom ok')\n"),
    ("crlf", "print('crlf ok')\r\nlocal x = 1\r\nprint(x)\r\n", None),
    ("long_string", "local s = [[\nline1 -- not a comment\nline2 ]]\nprint(#s, s:sub(1,5))\n", None),
    ("long_level2", "print([==[\n]] inside ]==])\n", None),
    ("utf8", "print('привет', #'äöü', '日本語')\n", None),
    ("nul_byte", "local s = 'a\\0b' print(#s, s:byte(2))\n", None),
    ("quotes", "print('it\\'s', \"a\\\"b\")\n", None),
    ("numbers", "print(0x10, 1e3, 3.75, 2^10, 7//2, .5)\n", None),
    ("semicolons", "local a=1; local b=2; print(a+b);\n", None),
    ("empty", "", None),
    ("comment_only", "-- nothing here\n", None),
    ("deep_nesting", "local t = {{a = {b = {c = {1,2,3}}}}} print(t[1].a.b.c[3])\n", None),
    ("goto_5_2plus", "local i = 0 ::top:: i = i + 1 if i < 3 then goto top end print(i)\n", None),
]


def main() -> int:
    fails = []
    checks = 0
    for name in V.RUNTIME_NAMES:
        V.RUNTIME = importlib.import_module(f"lupa.{name}")
        for cname, src, _ in CASES:
            normalized = LuaGuardNG(src, layers=1, seed=1).source
            ok_ref, ref = V.run_program(normalized, "plain")
            if not ok_ref:
                print(f"SKIP {name} {cname}: original does not run: {ref}")
                continue
            for layers, seed in ((2, 3), (3, 11)):
                checks += 1
                try:
                    obf = LuaGuardNG(src, layers=layers, seed=seed).build()
                except Exception as e:  # noqa: BLE001
                    fails.append(f"BUILD {name} {cname} layers={layers}: {e}")
                    continue
                ok, out = V.run_program(obf, "plain")
                if not ok or [V._norm(v) for v in out] != [V._norm(v) for v in ref]:
                    fails.append(f"RUN   {name} {cname} layers={layers}: "
                                 f"{out if ok else out!r} != {list(ref)!r}")
    V.RUNTIME = lupa
    print(f"edge cases: {checks} checks, failures: {len(fails)}")
    for f in fails[:30]:
        print("  -", f)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
