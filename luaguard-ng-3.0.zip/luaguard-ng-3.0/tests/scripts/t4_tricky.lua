-- tricky literals: long strings, long comments, escapes
--[[ this is a
multi-line comment with code-like text
local x = "not real code" ]]
local long = [[line one
line two "quotes" and ]] .. "\n"
print(#long, long:sub(1, 8))
local esc = "tab\there\nnew\"quote\\back"
print(esc)
print(0x10, 1e3, 3.5e-2)
local a = 1 ; local b = 2 ; print(a+b)
