-- global side effects + shared state between chunks
COUNTER = (COUNTER or 0) + 1
local function bump() COUNTER = COUNTER + 10 end
bump()
print("counter", COUNTER)
local shared = setmetatable({}, {__index = function() return "default" end})
print(shared.anything)
