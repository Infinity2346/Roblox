-- metatables, inheritance, string ops, math
local Vec = {}
Vec.__index = Vec
function Vec.new(x, y) return setmetatable({x=x, y=y}, Vec) end
function Vec.__add(a, b) return Vec.new(a.x+b.x, a.y+b.y) end
function Vec.__tostring(v) return "("..v.x..","..v.y..")" end
local a, b = Vec.new(1,2), Vec.new(3,4)
print(tostring(a+b))
local words = {"pear","apple","fig"}
table.sort(words)
print(table.concat(words, "/"))
print(math.max(3,9,2), math.sqrt(81), ("%d%%"):format(75))
local s = "abcdef"
print(s:sub(2,4), s:find("cd"), #("x"):rep(5))
local acc = 0
for i=1,5 do for j=1,5 do if (i*j) % 3 == 0 then acc = acc + 1 end end end
print("acc", acc)
