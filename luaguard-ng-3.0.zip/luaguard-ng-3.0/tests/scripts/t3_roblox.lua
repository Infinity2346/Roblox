-- roblox-like api usage
local Players = game:GetService("Players")
print("Players ok:", type(Players))
local Remote = game:HttpGet("https://example.com/api")
print("remote:", Remote)
local t = {1,2,3}
table.insert(t, 4)
print(#t, t[4])
