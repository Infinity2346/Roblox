-- basic arithmetic / strings / tables
local function fib(n) if n < 2 then return n end return fib(n-1) + fib(n-2) end
local t = {}
for i = 1, 10 do t[i] = fib(i) * 2 end
print("sum", table.concat(t, ","))
local s = "hello" .. " " .. "world"
print(s:upper(), #s, string.format("%d-%s", 42, "x"))
local mt = setmetatable({}, {__index = function(_, k) return k .. "!" end})
print(mt.foo, mt.bar)
