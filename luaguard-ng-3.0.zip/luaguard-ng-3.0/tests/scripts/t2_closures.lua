-- closures, varargs, pcall, coroutines
local function counter()
  local n = 0
  return function() n = n + 1 return n end
end
local c = counter()
print(c(), c(), c())
local function sum(...)
  local s = 0
  for _, v in ipairs({...}) do s = s + v end
  return s, select("#", ...)
end
print(sum(1,2,3,4,5))
local ok, err = pcall(function() error("boom") end)
print("pcall:", ok, err)
local co = coroutine.create(function(a) local b = coroutine.yield(a + 1) return b * 2 end)
print(coroutine.resume(co, 10))
print(coroutine.resume(co, 7))
