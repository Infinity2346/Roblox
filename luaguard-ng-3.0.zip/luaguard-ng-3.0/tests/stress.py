#!/usr/bin/env python3
"""
Randomized stress test: many random builds, random payloads, random layer counts,
random seeds and both environments.  Any mismatch / non-recoverable payload is a failure.
Usage: python3 tests/stress.py [rounds]
"""
from __future__ import annotations

import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from obfuscator_ng import LuaGuardNG  # noqa: E402
from tests.verify import run_capture, run_program  # noqa: E402

TEMPLATES = [
    "local a={} for i=1,@n@ do a[i]=i*@k@%97 end local s=0 for _,v in ipairs(a) do s=s+v end print('t1',s)",
    "local f=function(x) @rec@ end print('t2',f(@n@))",
    "local s='' for i=1,@n@ do s=s..string.char(97+i%26) end print('t3',#s,s:sub(1,3))",
    "local ok,e=pcall(function() error('e'..@n@) end) print('t4',ok,tostring(e):sub(-3))",
    "local t=setmetatable({},{__index=function(_,k) return k*@k@ end}) print('t5',t[@n@])",
    "local c=0 for i=1,@n@ do for j=1,@n@ do if (i+j)%3==0 then c=c+1 end end end print('t6',c)",
]


def payload(rng: random.Random) -> str:
    n = rng.randint(1, 20)
    src = "\n".join(
        rng.choice(TEMPLATES)
           .replace("@rec@", "if x<=1 then return 1 end return x*f(x-1)")
           .replace("@n@", str(rng.randint(1, 9)))
           .replace("@k@", str(rng.randint(2, 9)))
        for _ in range(rng.randint(1, 6)))
    extra = "".join("\nlocal v%d = %d + %d print('x%d', v%d)" % (i, i * 3, n, i, i)
                    for i in range(rng.randint(0, 10)))
    return src + extra + "\n"


def main() -> int:
    rounds = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    rng = random.Random(2026)
    fails = 0
    t0 = time.time()
    for r in range(1, rounds + 1):
        src = payload(rng)
        seed = rng.randrange(1, 1 << 30)
        layers = rng.randint(1, 4)
        decoys = rng.randint(0, 3)
        env = rng.choice(["plain", "roblox", "noload"])
        try:
            prod = LuaGuardNG(src, layers=layers, seed=seed, decoys=decoys).build()
            audit = LuaGuardNG(src, layers=layers, seed=seed, guard=False, decoys=0).build()
        except Exception as e:  # noqa: BLE001
            print(f"[{r}] BUILD FAIL seed={seed} layers={layers}: {e}")
            fails += 1
            continue
        ok_ref, ref = run_program(src, env)
        if not ok_ref:
            continue
        ok, got = run_program(prod, env)
        if not ok or list(got) != list(ref):
            print(f"[{r}] RUN FAIL seed={seed} layers={layers} env={env}: "
                  f"{got if ok else got}")
            fails += 1
            continue
        okc, caps, err = run_capture(audit, env)
        if not okc or src not in caps:
            print(f"[{r}] AUDIT FAIL seed={seed} layers={layers} env={env}: {err or 'not recovered'}")
            fails += 1
            continue
        print(f"[{r}] ok  seed={seed:<11} layers={layers} env={env:<7} "
              f"payload={len(src):5d}B  out={len(prod):7d}B")
    print(f"\nrounds: {rounds}, failures: {fails}, elapsed: {time.time()-t0:.1f}s")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
