#!/usr/bin/env python3
"""
LuaGuard NG 3.0 — hardened Lua obfuscator (Roblox / Lua 5.1-5.5 / LuaJIT).

FIXES vs the original `obfuscator_max.txt`
  F1  No bit32 / bit / native bit ops anywhere (the original needed bit32 and therefore did
      *nothing at all* on plain Lua 5.4/5.5).
  F2  No static key material: every layer builds a fresh cipher instance (key, salts, S-boxes,
      round constants, feedback rule) hidden inside arithmetic expressions.
  F3  No recognizable skeleton: cipher, text codec, string-reassembly shape, control-flow
      shape and naming all change per layer and per build.
  F4  Fragments are cut at random, non token-aligned lengths.
  F5  Integrity is not an oracle: a wrong decryption or a tampered blob yields empty strings
      and a quiet decoy, never an error or a "checksum failed" beacon.
  F6  Anti-instrumentation: two independent identity channels (debug.info/debug.getinfo and
      string.dump), active-debug-hook detection, wrapped core-function detection, stripped
      debug detection, loader-semantics probes.
  F7  Runtime salt: an instrumented runtime gets a poisoned decryption, so the payload never
      materialises - patching the guard's branch does not help either.
  F8  Decoys are plausible, harmless scripts that print plausible lines, so a thief sees a
      "working" result; junk scripts are pushed through the loader as noise.
  F9  No buggy minifier pass (the original's minifier corrupted `[[...]]` long strings).
  F10 Self-verification: `--test` runs the result on every Lua implementation lupa ships
      (5.1, 5.2, 5.3, 5.4, 5.5, LuaJIT 2.0/2.1) plus a byte-exact audit of the payload.

NEW in 3.0 (on top of 2.1)
  N1  Control-flow flattening: each layer's statements are emitted as a randomised dispatcher
      (if/elseif chain, closure table or closure stream) with random state ids and shuffled
      block order - reading the file top-to-bottom tells you nothing.
  N2  Library names are never written literally: they are split into random concatenations in
      a shuffled name table (`NH[7]` instead of 'string.char'), so pattern scanners see no
      API names at all.
  N3  Fragment storage: all fragments (real, decoy, junk) live inside ONE gibberish literal
      plus an offset/length index; junk is inseparable from data by a static reader.
  N4  Integrity value depends on the runtime salt, so zeroing the salt alone does not reveal
      the payload.
  N5  Reader-function loader path where the runtime supports it (Lua 5.2+): the source is
      handed to `load` as a *function*, so a naive hook that logs the string argument logs
      nothing.
  N6  Two more cipher families (`spn8`, `feistel2`) and randomised soft-probe subsets.

Usage:
  python3 obfuscator_ng.py input.lua -o output.lua --layers 3 --test
  python3 obfuscator_ng.py input.lua -o output.lua --layers 4 --seed 12345
"""

from __future__ import annotations

import argparse
import os
import random
import secrets
import sys
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import CIPHERS, Namer, frame  # noqa: E402
from lcodecs import CODECS  # noqa: E402

CODEC_COST = {"b64": 1.35, "hex": 2.05, "numerals": 3.1, "cards": 4.2, "words": 7.5}

# harmless decoys that look like real Roblox utility scripts; they print plausible lines so a
# deobfuscation attempt that lands on them looks successful
DECOYS = [
    "print('[init] loader 2.4.1')\n"
    "local s = 0 for i = 1, 32 do s = s + (i * 7) % 251 end\n"
    "print('[init] modules', s % 97)\n"
    "pcall(function() local p = game:GetService('Players') if p and p.LocalPlayer then "
    "print('[init] user', p.LocalPlayer.Name) end end)\n",

    "print('[ui] building interface')\n"
    "local f = { tabs = {'Main', 'Settings', 'Info'}, open = false }\n"
    "for i = 1, #f.tabs do f[i] = f.tabs[i] end\n"
    "print('[ui] tabs ready:', #f.tabs)\n",

    "print('[stats] collecting')\n"
    "local acc, best = 0, 0\n"
    "for i = 1, 24 do acc = (acc + i * i) % 8191 if acc > best then best = acc end end\n"
    "print('[stats] score', best)\n",

    "print('[net] checking endpoint')\n"
    "local ok = pcall(function() return game:HttpGet('https://example.invalid/version') end)\n"
    "print('[net] reachable:', ok)\n",

    "print('[guard] integrity pass')\n"
    "local t = {} for i = 1, 16 do t[i] = (i * 13) % 256 end\n"
    "local h = 0 for _, v in ipairs(t) do h = (h * 31 + v) % 65521 end\n"
    "print('[guard] digest', h)\n",

    "print('[main] started')\n"
    "local cfg = { fps = 60, debug = false, autosave = true }\n"
    "if cfg.fps > 30 then print('[main] performance mode') end\n"
    "print('[main] ready')\n",
]

# harmless chunks pushed through the loader as noise for hook loggers
JUNK_CHUNKS = [
    "local t={} for i=1,4 do t[i]=i end return t",
    "local s='' for i=1,3 do s=s..i end return s",
    "return function() local x=1 return x end",
    "local m={} function m.a() return 2 end return m.a()",
    "local q=0 for i=1,5 do q=q+i end return q",
]

# library names that must never appear as literals in the output
NAME_KEYS = ["load", "loadstring", "debug", "info", "getinfo", "gethook", "string", "char",
             "table", "concat", "math", "floor", "dump", "game", "setfenv", "getfenv",
             "rawget", "typeof", "sub", "byte", "rep", "format"]


# ------------------------------------------------------------------ small helpers
def lua_str(s: str) -> str:
    """Safe single-quoted Lua string literal."""
    out = (s.replace("\\", "\\\\").replace("'", "\\'")
            .replace("\n", "\\n").replace("\r", "\\r"))
    return "'" + out + "'"


def cut_random(s: str, rng: random.Random) -> List[str]:
    """Split a stream into fragments.  Piece size grows with the payload so the fragment
    index (which costs ~25 bytes per piece) never dominates the file size."""
    out, i = [], 0
    piece = max(19, min(4096, len(s) // 48))
    while i < len(s):
        n = rng.randint(piece, piece * 3)
        out.append(s[i:i + n])
        i += n
    return out


def pad_payload(text: str, target_len: int) -> str:
    if len(text) >= target_len:
        return text
    need = target_len - len(text) - 12
    return text + "\n--[[" + ("." * max(0, need)) + "]]"


# library-qualified names that the emitters would otherwise write literally; they are
# rewritten into `SC[NH[k]]` / `TC[NH[k]]` / `MF[NH[k]]` lookups (see `hide_api`)
QUOTED_API = {
    "string": ["char", "sub", "byte", "dump", "rep", "format"],
    "table": ["concat"],
    "math": ["floor", "min", "max"],
}


def capture_api(nm: Namer, nh: NameTable, names: Tuple[str, str, str]) -> str:
    """Capture the string / table / math libraries into locals taken from `_G` via NH.

    The locals live in one function scope and are reused by `hide_api` replacements.
    """
    sc, tc, mf = names
    return (f"local {sc}, {tc}, {mf}=rawget(_G,{nh('string')}), rawget(_G,{nh('table')}), "
            f"rawget(_G,{nh('math')}) ")


def hide_api(code: str, nh: NameTable, names: Tuple[str, str, str]) -> str:
    """Replace `string.char`, `table.concat`, ... with `SC[NH[k]]` style lookups.

    Only code regions are rewritten: string literals are copied verbatim, so the encrypted
    blob (and the name table itself) survive untouched.
    """
    sc, tc, mf = names
    tables = {"string": sc, "table": tc, "math": mf}
    out: List[str] = []
    i, n = 0, len(code)
    while i < n:
        ch = code[i]
        if ch in "'\"":
            j = i + 1
            while j < n:
                if code[j] == "\\":
                    j += 2
                    continue
                if code[j] == ch:
                    j += 1
                    break
                j += 1
            out.append(code[i:j])
            i = j
            continue
        if ch == "-" and code.startswith("--", i):
            j = code.find("\n", i)
            j = n if j < 0 else j
            out.append(code[i:j])
            i = j
            continue
        if ch.isalpha() or ch == "_":
            j = i
            while j < n and (code[j].isalnum() or code[j] == "_"):
                j += 1
            word = code[i:j]
            if code[j:j + 1] == "." and word in tables:
                k = j + 1
                while k < n and (code[k].isalnum() or code[k] == "_"):
                    k += 1
                meth = code[j + 1:k]
                if meth in QUOTED_API[word]:
                    out.append(f"{tables[word]}[{nh(meth)}]")
                    i = k
                    continue
            out.append(word)
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)


class NameTable:
    """Maps logical library names to `NH[k]` lookups with a per-build shuffled index order."""

    def __init__(self, nm: Namer, rng: random.Random):
        self.var = nm.n()
        order = list(range(1, len(NAME_KEYS) + 1))
        rng.shuffle(order)
        self.idx = {key: order[i] for i, key in enumerate(NAME_KEYS)}
        self.rng = rng

    def __call__(self, key: str) -> str:
        return f"{self.var}[{self.idx[key]}]"

    def decl(self) -> str:
        lines = []
        for i, key in enumerate(NAME_KEYS):
            pieces = []
            pos = 0
            while pos < len(key):                      # split into random concatenation pieces
                step = self.rng.randint(1, max(1, len(key) - pos))
                pieces.append(key[pos:pos + step])
                pos += step
            if len(pieces) == 1:
                pieces = [key[:1], key[1:]] if len(key) > 1 else pieces
            lines.append(f"{self.var}[{self.idx[key]}]=" + "..".join(lua_str(p) for p in pieces))
        self.rng.shuffle(lines)
        return " ".join(lines) + " "

    def declare(self) -> str:
        """Declaration for the name table; must sit in the function scope, not in a chunk."""
        return f"local {self.var}={{}} "


def strip_locals(code: str) -> str:
    """`local A={...} local B={...}` -> `A={...} B={...}` so the names can be pre-declared."""
    return code.replace("local ", "")


def flatten_chunks(chunks: List[str], nm: Namer, rng: random.Random) -> str:
    """Emit a statement list as a randomised dispatcher (control-flow flattening).

    The *execution* order is always the original order; what is randomised is the layout:
    state ids, the order in which the branches/functions appear in the file, and the
    dispatcher shape itself (if/elseif chain, closure table, closure stream).
    """
    chunks = [c for c in chunks if c.strip()]
    if len(chunks) == 1:
        return chunks[0]
    ids = rng.sample(range(100001, 999999), len(chunks))
    chain = list(zip(ids, chunks, ids[1:] + [0]))               # id -> chunk -> next id
    style = rng.choice(["chain", "chain", "table", "stream"])
    st = nm.n()
    shuffled = list(chain)
    if style in ("chain", "table"):
        rng.shuffle(shuffled)
    if style == "chain":
        parts = []
        for n, (i, c, nxt) in enumerate(shuffled):
            kw = "if" if n == 0 else "elseif"
            parts.append(f"{kw} {st}=={i} then do {c} end {st}={nxt}")
        body = " ".join(parts) + f" else {st}=0 end"
        return (f"local {st}={ids[0]} while {st}~=nil and {st}~=0 do {body} end ")
    if style == "table":
        F, NX = nm.n(), nm.n()
        defs = " ".join(f"{F}[{i}]=function() {c} end {NX}[{i}]={nxt}"
                        for i, c, nxt in shuffled)
        return (f"local {F}, {NX}, {st}={{}}, {{}}, {ids[0]} " + defs +
                f" while {st}~=nil and {st}~=0 do local g={F}[{st}] if g then g() end "
                f"{st}={NX}[{st}] end ")
    # stream: ordered closure table walked by a counter (definitions emitted shuffled)
    F, i = nm.n(), nm.n()
    defs = [f"{F}[{pos}]=function() {c} end" for pos, (_, c, _) in enumerate(chain, start=1)]
    rng.shuffle(defs)
    return (f"local {F}, {i}={{}}, 0 " + " ".join(defs) +
            f" while {i}<#{F} do {i}={i}+1 local g={F}[{i}] if g then g() end end ")


def concat_code(tbl: str, idx_vector: List[int], nm: Namer, shape: str, rng: random.Random,
                nh: NameTable) -> str:
    """Lua EXPRESSION (IIFE) that concatenates fragments of table `tbl` in the given order."""
    ix, raw, i = nm.n(), nm.n(), nm.n()
    keys = ",".join(str(k) for k in idx_vector)
    if shape == "linear":
        body = (f"local {ix}={{{keys}}} local {raw}='' "
                f"for {i}=1,#{ix} do {raw}={raw}..{tbl}[{ix}[{i}]] end return {raw}")
    elif shape == "state":
        ops = ",".join("{%d}" % k for k in idx_vector)
        body = (f"local {ix}={{{ops}}} local {raw}='' local {i}=0 "
                f"while {i}<#{ix} do {i}={i}+1 {raw}={raw}..{tbl}[{ix}[{i}][1]] end return {raw}")
    elif shape == "recursive":
        fn, acc = nm.n(), nm.n()
        body = (f"local {ix}={{{keys}}} "
                f"local function {fn}({i},{acc}) if {i}>#{ix} then return {acc} end "
                f"return {fn}({i}+1,{acc}..{tbl}[{ix}[{i}]]) end return {fn}(1,'')")
    elif shape == "pairwise":
        out, a, b = nm.n(), nm.n(), nm.n()
        body = (f"local {ix}={{{keys}}} local {out}='' local {i}=1 "
                f"while {i}<=#{ix} do {a}={tbl}[{ix}[{i}]] "
                f"{b}={i}<#{ix} and {tbl}[{ix}[{i}+1]] or '' "
                f"{out}={out}..{a}..{b} {i}={i}+2 end return {out}")
    else:
        raise ValueError(shape)
    return "(function() " + body + " end)()"


def to_source_code(pv: str, out: str, nm: Namer, tag: bytes, salt: Optional[str] = None,
                   salt_mul: int = 0) -> str:
    """Bytes table (4-byte BE length + payload + 4-byte tag) -> Lua string, tag-checked.

    The expected tag value depends on the runtime salt when the guard is active: zeroing the
    salt alone therefore does not make a poisoned decryption look valid.
    """
    n, t, i, bad = nm.n(), nm.n(), nm.n(), nm.n()
    expected = f"({sum(tag) % 251}+{salt}*{salt_mul})%251" if salt else str(sum(tag) % 251)
    return (f"local {n}, {bad}, {t}, {i} {out}='' {n}={pv}[1]*16777216+{pv}[2]*65536+{pv}[3]*256+{pv}[4] "
            f"{bad}=false if {n}<0 or {n}+8>#{pv} then {bad}=true end "
            f"{t}={{}} for {i}=1,{n} do {t}[{i}]=string.char({pv}[{i}+4]) end "
            f"if not {bad} then "
            f"if ({pv}[{n}+5]+{pv}[{n}+6]+{pv}[{n}+7]+{pv}[{n}+8])%251~={expected} "
            f"then {bad}=true end end "
            f"{out}=table.concat({t}) if {bad} then {out}='' end ")


def loader_code(nm: Namer, nh: NameTable, L: Optional[str] = None,
                RD: Optional[str] = None) -> Tuple[str, str, str]:
    """Select a working string->chunk loader and remember whether reader functions work.

    `L` / `RD` must be pre-declared by the caller (they are shared across dispatcher chunks).
    """
    MK = nm.n()
    if L is None:
        L = nm.n()
    if RD is None:
        RD = nm.n()
    code = (f"local {MK}=function(f) if type(f)~='function' then return false end "
            f"local o,r=pcall(f,'return 1') return o and type(r)=='function' end "
            f"{L}=nil "
            f"if {MK}(rawget(_G,{nh('loadstring')})) then {L}=rawget(_G,{nh('loadstring')}) "
            f"elseif {MK}(rawget(_G,{nh('load')})) then {L}=rawget(_G,{nh('load')}) end "
            f"{RD}=false "
            f"if {L}~=nil then local o,r=pcall({L},function() return nil end) "
            f"{RD}=o and type(r)=='function' end ")
    return code, L, RD


def runtime_salt(nm: Namer, rng: random.Random, rs: str, nh: NameTable,
                 loader: str) -> str:
    """Assign a 0..255 runtime salt: 0 in a clean runtime, != 0 when instrumented."""
    D, S, T, M, W, INF, chk, chk2 = (nm.n() for _ in range(8))
    a = [rng.randrange(1, 256) for _ in range(7)]
    return (
        f"{rs}=0 "
        f"local {D}=rawget(_G,{nh('debug')}) "
        f"local {S}=rawget(_G,{nh('string')}) "
        f"local {T}=rawget(_G,{nh('table')}) "
        f"local {M}=rawget(_G,{nh('math')}) "
        f"local {INF}=nil "
        f"if type({D})=='table' then "
        f"if type({D}[{nh('info')}])=='function' then "
        f"{INF}=function(f) local o,r=pcall({D}[{nh('info')}],f,'s') "
        f"if o and type(r)=='table' then return r end end "
        f"elseif type({D}[{nh('getinfo')}])=='function' then "
        f"{INF}=function(f) local o,r=pcall({D}[{nh('getinfo')}],f,'S') "
        f"if o and type(r)=='table' then return r end end end end "
        f"local function {chk}({W}) if type({W})~='function' or {INF}==nil then return 0 end "
        f"local r={INF}({W}) if r and r.what=='Lua' then return 1 end return 0 end "
        # second, independent channel that does not trust `debug` at all: string.dump refuses
        # C functions and dumps Lua closures, so wrappers are revealed even if debug lies
        f"local function {chk2}({W}) if type({W})~='function' or {S}==nil or "
        f"type({S}[{nh('dump')}])~='function' then return 0 end "
        f"local o,r=pcall({S}[{nh('dump')}],{W}) if o and type(r)=='string' then return 1 end "
        f"return 0 end "
        f"if {loader}==nil then {rs}={rs}+{a[6]} end "
        f"if type({D})=='table' and type({D}[{nh('gethook')}])=='function' then "
        f"local o,k=pcall({D}[{nh('gethook')}]) if o and k~=nil then {rs}={rs}+{a[0]} end end "
        f"{rs}={rs}+{a[1]}*{chk}({loader}) "
        f"{rs}={rs}+{a[2]}*{chk}({S} and rawget({S},{nh('char')})) "
        f"{rs}={rs}+{a[3]}*{chk}({T} and rawget({T},{nh('concat')})) "
        f"{rs}={rs}+{a[4]}*{chk}({M} and rawget({M},{nh('floor')})) "
        f"{rs}={rs}+{a[1]}*{chk2}({loader}) "
        f"{rs}={rs}+{a[2]}*{chk2}({S} and rawget({S},{nh('char')})) "
        f"{rs}={rs}+{a[3]}*{chk2}({T} and rawget({T},{nh('concat')})) "
        f"{rs}={rs}+{a[4]}*{chk2}({M} and rawget({M},{nh('floor')})) "
        f"{rs}={rs}+{a[5]}*{chk2}({S} and rawget({S},{nh('dump')})) "
        f"if type(rawget(_G,{nh('game')}))=='table' and {INF}==nil then {rs}={rs}+{a[5]} end "
        f"{rs}={rs}%256 ")


def poison_code(blob: str, salt: str, nm: Namer, rng: random.Random) -> str:
    """Fold the runtime salt into the decoded byte stream (exact no-op when salt == 0)."""
    k1, k2 = nm.n(), nm.n()
    m1, m2 = rng.randrange(3, 251), rng.randrange(3, 251)
    return (f"local {k1}=math.floor(({salt}*{m1})%256) "
            f"local {k2}=math.floor(({salt}*{m2})%256) "
            f"{blob}[1]=math.floor(({blob}[1]+{k1})%256) "
            f"{blob}[#{blob}]=math.floor(({blob}[#{blob}]+{k2})%256) ")


# ------------------------------------------------------------------ guard / execution
def guard_and_exec(nm: Namer, nh: NameTable, src_real: str, src_decoy: str,
                   rng: random.Random, decoys: int, api: Tuple[str, str, str]) -> str:
    """Flattened dispatcher that decides between the real payload and the decoy, then runs it."""
    D, S, T, M, INF, chk, chk2 = (nm.n() for _ in range(7))
    L, RD, MK = nm.n(), nm.n(), nm.n()
    ok, score, srcd, F, good, q = (nm.n() for _ in range(6))

    pre = (f"{nh.declare()} {nh.decl()} {capture_api(nm, nh, api)}"
           f"local {D}, {S}, {T}, {M}, {INF}, {chk}, {chk2}, {L}, {RD}, {MK}, "
           f"{ok}, {score}, {srcd}, {F}, {good}, {q} ")
    chunks: List[str] = []

    lcode, L, RD = loader_code(nm, nh, L, RD)
    chunks.append(f"{lcode} {ok}={L}~=nil {score}=0 ")

    chunks.append(f"{D}=rawget(_G,{nh('debug')}) {S}=rawget(_G,{nh('string')}) "
                  f"{T}=rawget(_G,{nh('table')}) {M}=rawget(_G,{nh('math')}) "
                  f"{INF}=nil "
                  f"if type({D})=='table' then "
                  f"if type({D}[{nh('info')}])=='function' then "
                  f"{INF}=function(f) local o,r=pcall({D}[{nh('info')}],f,'s') "
                  f"if o and type(r)=='table' then return r end end "
                  f"elseif type({D}[{nh('getinfo')}])=='function' then "
                  f"{INF}=function(f) local o,r=pcall({D}[{nh('getinfo')}],f,'S') "
                  f"if o and type(r)=='table' then return r end end end end ")
    chunks.append(f"{chk}=function({q}) if type({q})~='function' or {INF}==nil then return 0 end "
                  f"local r={INF}({q}) if r and r.what=='Lua' then return 1 end return 0 end "
                  f"{chk2}=function({q}) if type({q})~='function' or {S}==nil or "
                  f"type({S}[{nh('dump')}])~='function' then return 0 end "
                  f"local o,r=pcall({S}[{nh('dump')}],{q}) "
                  f"if o and type(r)=='string' then return 1 end return 0 end ")

    hard = [
        f"if {ok} and {chk}({L})==1 then {ok}=false end ",
        f"if {ok} and {chk2}({L})==1 then {ok}=false end ",
        f"if {ok} and type({D})=='table' and {D}[{nh('info')}]~=nil "
        f"and {chk}({L})==1 then {ok}=false end ",
        # a healthy loader REFUSES a syntax error: it either raises (5.1) or returns
        # nil+message (5.2+).  A dumb capture-hook that hands the source back is caught here.
        f"if {ok} then {good},{q}=pcall({L},')') "
        f"if good and type({q})=='function' then {ok}=false end end ",
        f"if {ok} then if type({L}('return 1'))~='function' then {ok}=false end end ",
        f"if {ok} then if type({L}(''))~='function' then {ok}=false end end ",
        f"if {ok} then if type({L}('local a=1'))~='function' then {ok}=false end end ",
        f"if {ok} and {chk2}({S} and rawget({S},{nh('char')}))==1 then {ok}=false end ",
        f"if {ok} and {chk2}({T} and rawget({T},{nh('concat')}))==1 then {ok}=false end ",
        f"if {ok} and type(rawget(_G,{nh('game')}))=='table' and {INF}==nil then {ok}=false end ",
        f"if {ok} and type({D})=='table' and type({D}[{nh('gethook')}])=='function' then "
        f"local o,k=pcall({D}[{nh('gethook')}]) if o and k~=nil then {ok}=false end end ",
    ]
    soft = [
        f"if string.char(65)=='A' then {score}={score}+1 end ",
        f"if ('ab'):rep(2)=='abab' then {score}={score}+1 end ",
        f"if select('#',1,2,3)==3 then {score}={score}+1 end ",
        f"if math.floor(3.7)==3 then {score}={score}+1 end ",
        f"if tostring(7)=='7' then {score}={score}+1 end ",
        f"if type(rawget(_G,{nh('game')}))=='table' "
        f"and type(rawget(_G,{nh('typeof')}))=='function' then {score}={score}+1 end ",
        f"if getmetatable('') and getmetatable('').__index==string then {score}={score}+1 end ",
        f"if tostring({L}):find('builtin') then {score}={score}+1 end ",
        f"if #tostring({L})>6 then {score}={score}+1 end ",
        f"if type(pcall)=={lua_str('function')} then {score}={score}+1 end ",
    ]
    chunks += hard
    rng.shuffle(soft)
    chunks += soft                      # every soft probe is used, only the order is random
    threshold = rng.choice([3, 3, 4])   # a healthy runtime scores 7..10, a stripped one 0..3

    noise = [f"pcall(function() local z={L}({lua_str(rng.choice(JUNK_CHUNKS))}) "
             f"if z then z() end end) " for _ in range(decoys)]
    chunks += noise

    chunks.append(f"if #({src_real})==0 then {ok}=false end "
                  f"{srcd}={src_decoy} "
                  f"if {ok} and {score}>={threshold} then {srcd}={src_real} end ")

    exec_chunk = (f"{F}=nil "
                  f"if {RD} then local dn=false "
                  f"local o,r=pcall({L},function() if dn then return nil end dn=true "
                  f"return {srcd} end) "
                  f"if o and type(r)=='function' then {F}=r end end "
                  f"if {F}==nil then {F}={L}({srcd}) end "
                  f"if {F} then "
                  f"local SE=rawget(_G,{nh('setfenv')}) local GE=rawget(_G,{nh('getfenv')}) "
                  f"if SE then pcall(SE,{F},GE and GE() or _G) end {F}() end ")
    chunks.append(exec_chunk)

    return pre + flatten_chunks(chunks, nm, rng)


# ------------------------------------------------------------------ one layer
def build_layer(inner: bytes, rng: random.Random, nm: Namer, tag: bytes, *, guard: bool,
                decoys: int, cipher_cls, codec_cls, nh: NameTable,
                api: Tuple[str, str, str]) -> str:
    cipher = cipher_cls(rng)
    codec = codec_cls(rng)

    ct = cipher.encrypt(frame(inner) + tag)
    ct += bytes((16 - len(ct) % 16) % 16)
    decoy_len = min(700, max(48, len(inner) // 4 + 64))
    decoy_src = pad_payload(rng.choice(DECOYS), decoy_len).encode()
    dct = cipher.encrypt(frame(decoy_src) + tag)
    dct += bytes((16 - len(dct) % 16) % 16)

    raw_r = codec.encode(ct)
    raw_d = codec.encode(dct) if guard else ""

    fr = cut_random(raw_r, rng)
    fd = cut_random(raw_d, rng) if guard else []
    junk = ["".join(rng.choice("abcdefghijkmnpqrstuvwxyz0123456789")
                    for _ in range(rng.randint(11, 40)))
            for _ in range(rng.randint(3, 7))]

    # every fragment (real, decoy, junk) goes into ONE blob at a shuffled key, with random
    # filler between fragments, so a static reader cannot tell data from noise
    items = [("r", i, t) for i, t in enumerate(fr)] \
        + [("d", i, t) for i, t in enumerate(fd)] \
        + [("j", i, t) for i, t in enumerate(junk)]
    rng.shuffle(items)
    FT, BLOB, OB, LB = nm.n(), nm.n(), nm.n(), nm.n()

    parts: List[str] = []
    off = 0
    idx_lines: List[str] = []
    keys_real = [0] * len(fr)
    keys_decoy = [0] * len(fd)
    for k, (kind, orig, text) in enumerate(items, start=1):
        idx_lines.append(f"{OB}[{k}]={off} {LB}[{k}]={len(text)}")
        parts.append(text)
        off += len(text)
        filler = "".join(rng.choice("abcdefghijkmnpqrstuvwxyz0123456789")
                         for _ in range(rng.randint(0, 9)))
        parts.append(filler)                      # filler is never referenced
        off += len(filler)
        if kind == "r":
            keys_real[orig] = k
        elif kind == "d":
            keys_decoy[orig] = k
    blob_text = "".join(parts)
    rng.shuffle(idx_lines)

    shape = rng.choice(["linear", "state", "recursive", "pairwise"])
    pro_r, env_r = cipher.lua_material(nm)
    pro_d, env_d = cipher.lua_material(nm)

    NH = nh.var
    RAW_R, RAW_D = nm.n(), nm.n()
    B_R, B_D, P_R, P_D = (nm.n() for _ in range(4))
    SRC_R, SRC_D = nm.n(), nm.n()
    RS = nm.n()
    L, RD = nm.n(), nm.n()
    pk = nm.n()
    salt_mul = rng.randrange(3, 251)

    # cross-chunk names are declared once, so any chunk can live in its own block/closure
    declared = [FT, BLOB, OB, LB, RAW_R, B_R, P_R, SRC_R] + list(env_r.values())
    if guard:
        declared += [RAW_D, B_D, P_D, SRC_D, RS, L, RD] + list(env_d.values())

    chunks: List[str] = []
    if guard:
        lcode, L, RD = loader_code(nm, nh, L, RD)
        chunks.append(lcode)
        chunks.append(runtime_salt(nm, rng, RS, nh, L))
    chunks.append(strip_locals(pro_r))
    chunks.append(f"local {BLOB}..." if False else (
        f"{BLOB}={lua_str(blob_text)} {OB}={{}} {LB}={{}} " + " ".join(idx_lines) +
        f" {FT}={{}} for i=1,#{OB} do {FT}[i]={BLOB}:sub({OB}[i]+1,{OB}[i]+{LB}[i]) end "))
    chunks.append(f"{RAW_R}=" + concat_code(FT, keys_real, nm, shape, rng, nh))
    chunks.append(codec.lua_decode(nm, RAW_R, B_R))
    if guard:
        chunks.append(poison_code(B_R, RS, nm, rng))
    chunks.append(cipher.lua_decode(nm, B_R, P_R, env_r))
    chunks.append(to_source_code(P_R, SRC_R, nm, tag, RS if guard else None, salt_mul))
    if guard:
        chunks.append(strip_locals(pro_d))
        chunks.append(f"{RAW_D}=" + concat_code(FT, keys_decoy, nm, shape, rng, nh))
        chunks.append(codec.lua_decode(nm, RAW_D, B_D))
        chunks.append(poison_code(B_D, RS, nm, rng))
        chunks.append(cipher.lua_decode(nm, B_D, P_D, env_d))
        chunks.append(to_source_code(P_D, SRC_D, nm, tag, RS, salt_mul))

    decl = (nh.declare() + nh.decl() + capture_api(nm, nh, api)
            + "local " + ", ".join(declared) + " ")
    inner_code = decl + flatten_chunks(chunks, nm, rng)
    if guard:
        wrapped = (f"local {pk}, {SRC_R}, {SRC_D}=pcall(function() {inner_code} "
                   f"return {SRC_R}, {SRC_D} end) "
                   f"if not {pk} then {SRC_R}='' {SRC_D}='' end ")
    else:
        wrapped = (f"local {pk}, {SRC_R}=pcall(function() {inner_code} return {SRC_R} end) "
                   f"if not {pk} then {SRC_R}='' end ")

    if guard:
        exec_code = guard_and_exec(nm, nh, SRC_R, SRC_D, rng, decoys, api)
    else:
        F, L, RD = nm.n(), nm.n(), nm.n()
        lcode, L, RD = loader_code(nm, nh, L, RD)
        exec_code = (f"{nh.declare()} {nh.decl()} {capture_api(nm, nh, api)}"
                     f"local {F}, {L}, {RD} {lcode} "
                     f"{F}={L}({SRC_R}) if {F} then "
                     f"local SE=rawget(_G,{nh('setfenv')}) "
                     f"local GE=rawget(_G,{nh('getfenv')}) "
                     f"if SE then pcall(SE,{F},GE and GE() or _G) end {F}() end")
    return hide_api(wrapped + exec_code, nh, api)


# ------------------------------------------------------------------ driver
class LuaGuardNG:
    def __init__(self, source: str, layers: int = 3, seed: Optional[int] = None,
                 max_size: int = 1_000_000, guard: bool = True, decoys: int = 2,
                 guard_layers: int = 1):
        # normalise file artefacts: a UTF-8 BOM and a shebang line are fine for loadfile()
        # but make a *string* loader fail, so the obfuscated (string-loaded) copy must not
        # carry them.
        if source.startswith("\ufeff"):
            source = source[1:]
        if source.startswith("#!"):
            nl = source.find("\n")
            source = "" if nl < 0 else source[nl + 1:]
        self.source = source
        self.layers = max(1, min(layers, 6))
        self.seed = seed if seed is not None else int.from_bytes(secrets.token_bytes(8), "big")
        self.rng = random.Random(self.seed)
        self.nm = Namer(self.rng)
        self.max_size = max_size
        self.guard = guard
        self.decoys = decoys
        self.guard_layers = max(0, guard_layers)
        self.report: List[str] = []
        self.methods: List[Tuple[str, str]] = []
        self.made: set = set()

    def build(self) -> str:
        payload = self.source.encode()
        tag = bytes(self.rng.randrange(256) for _ in range(4))
        nh = NameTable(self.nm, self.rng)
        api = (self.nm.n(), self.nm.n(), self.nm.n())     # shared library-capture names
        for i in range(self.layers):
            # growth budget: keep every layer within a sane multiplier of its input
            room = self.max_size * 0.45 / max(1, len(payload) + 16)
            cap = 3.2 if len(payload) < 1500 else 2.2
            cap = min(cap, max(1.35, room))
            cands = [c for c in CODECS if CODEC_COST[c.name] <= cap]
            if not cands:
                self.report.append(f"layer {i+1}: size budget reached, stopping")
                break
            weights = [1.0 / (CODEC_COST[c.name] ** 4) for c in cands]
            codec_cls = self.rng.choices(cands, weights=weights, k=1)[0]
            pool = [c for c in CIPHERS if c not in self.made] or list(CIPHERS)
            cipher_cls = self.rng.choice(pool)
            self.made.add(cipher_cls)
            guarded = self.guard and (i >= self.layers - self.guard_layers)
            text = build_layer(payload, self.rng, self.nm, tag, guard=guarded,
                               decoys=self.decoys if guarded else 0,
                               cipher_cls=cipher_cls, codec_cls=codec_cls, nh=nh, api=api)
            self.methods.append((cipher_cls.shape, codec_cls.name))
            self.report.append(f"layer {i+1}: cipher={cipher_cls.shape:8s} codec={codec_cls.name:9s} "
                               f"{len(payload):7d}B -> {len(text):7d}B"
                               f"{'' if guarded else '  (inner layer, no guard stack)'}")
            payload = text.encode()
        self.report.append("methods: " + " -> ".join(f"{a}/{b}" for a, b in self.methods))
        return payload.decode()


# ------------------------------------------------------------------ CLI
# `--test` is fully self-contained: it needs only lupa, never the tests/ package, so it
# works from any directory and even if obfuscator_ng.py was copied out on its own.
_SC_PRELUDE = r"""
_out = {}
function print(...)
  local t = {}
  for i = 1, select('#', ...) do t[i] = tostring(select(i, ...)) end
  _out[#_out + 1] = table.concat(t, '\t')
end
"""

_SC_ROBLOX = _SC_PRELUDE + r"""
game = { GetService = function(self, n) return {Name = n} end,
         HttpGet = function(self, u) return 'print("REMOTE_STUB_OK")' end }
typeof = function(v) return type(v) end
if not rawget(_G, 'loadstring') then loadstring = load end
if not rawget(_G, 'getfenv') then getfenv = function() return _G end end
if not rawget(_G, 'setfenv') then setfenv = function(f, e) return f end end
task = { spawn = function(f) pcall(f) end, wait = function() end }
"""

_SC_NOLOAD = _SC_PRELUDE + r"""
if not rawget(_G, 'loadstring') then loadstring = load end
load = nil
"""

_SC_HOOK = r"""
_real_load = load
_real_ls = rawget(_G, 'loadstring')
_captured = {}
local function call_real(src, name, mode)
  if type(src) == 'string' and _real_ls then return _real_ls(src, name, mode) end
  return _real_load(src, name, mode)
end
local function hook(src, name, mode, env)
  if type(src) == 'string' then _captured[#_captured + 1] = src end
  if env == nil then return call_real(src, name, mode) end
  return _real_ls and _real_ls(src, name, mode, env) or _real_load(src, name, mode, env)
end
load = hook
if _real_ls then loadstring = hook end
"""

_SC_ENVS = {"plain": _SC_PRELUDE, "roblox": _SC_ROBLOX, "noload": _SC_NOLOAD}
_SC_RT_NAMES = ["lua51", "lua52", "lua53", "lua54", "lua55", "luajit20", "luajit21"]


def _sc_norm(x):
    import re as _re
    if isinstance(x, str):
        x = _re.sub(r"\[string \"[^\"]*\"\]", "[chunk]", x)
        x = _re.sub(r"\((load|loadstring)\)", "[chunk]", x)
    return x


def _sc_runtimes():
    """[(label, module)] for every Lua implementation this lupa build exposes."""
    import importlib
    try:
        import lupa  # noqa: F401
    except Exception:  # noqa: BLE001
        return []
    out = []
    for name in _SC_RT_NAMES:
        try:
            out.append((name, importlib.import_module("lupa." + name)))
        except Exception:  # noqa: BLE001
            continue
    if not out:
        out.append(("lupa", lupa))
    return out


def _sc_run(mod, code: str, env: str):
    """Execute `code` in a fresh VM of `mod`; return (ok, [printed lines] | error)."""
    rt = mod.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(_SC_ENVS[env])
    try:
        rt.execute(code)
    except Exception as e:  # noqa: BLE001
        return False, _sc_norm(str(e).splitlines()[0])
    n = int(rt.eval("#_out"))
    return True, [rt.eval("_out[%d]" % i) for i in range(1, n + 1)]


def _sc_capture(mod, code: str, env: str):
    """Run `code` with a hooked loader and return every source string handed to it."""
    rt = mod.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(_SC_ENVS[env])
    if env == "noload":
        rt.execute("load = loadstring")
    rt.execute(_SC_HOOK)
    try:
        rt.execute(code)
    except Exception as e:  # noqa: BLE001
        return False, [], str(e).splitlines()[0]
    n = int(rt.eval("#_captured"))
    return True, [rt.eval("_captured[%d]" % i) for i in range(1, n + 1)], ""


def self_check(src: str, out: str, seed: int, layers: int, guard: bool = True) -> int:
    """Run the produced file for real on every Lua implementation lupa ships (plain,
    Roblox-like and loadless environments) and audit byte-exact payload recovery."""
    mods = _sc_runtimes()
    if not mods:
        print("[!] self-check пропущен: модуль lupa не найден")
        print("    установи:  pip install lupa      (в Termux: pip install lupa)")
        print("    без lupa запустить Lua-код нельзя, сам обфускатор работает и без него")
        return 0
    fails: List[str] = []
    checks = 0
    for label, mod in mods:
        line = []
        for env in ("plain", "roblox", "noload"):
            ok_ref, ref = _sc_run(mod, src, env)
            if not ok_ref:
                line.append(f"{env}:n/a")
                continue
            ok, got = _sc_run(mod, out, env)
            checks += 1
            if not ok:
                line.append(f"{env}:ОШИБКА")
                fails.append(f"{label}/{env}: запуск упал: {got}")
            elif [_sc_norm(v) for v in got] != [_sc_norm(v) for v in ref]:
                line.append(f"{env}:РАСХОЖДЕНИЕ")
                fails.append(f"{label}/{env}: вывод {list(got)} != {list(ref)}")
            else:
                line.append(f"{env}:ok")
        print(f"[+] {label:9s} " + "  ".join(line))
    audit = LuaGuardNG(src, layers=layers, seed=seed, guard=False, decoys=0).build()
    okc, caps, err = _sc_capture(mods[0][1], audit, "roblox")
    if not okc or src not in caps:
        print(f"[!] audit: полезная нагрузка не восстановлена байт-в-байт "
              f"({err or 'не совпало'})")
        fails.append("audit: не расшифровалось в исходник")
    else:
        print("[+] audit: двойник без защиты расшифровывается в исходник байт-в-байт")
    print(f"[+] self-check: проверок {checks}, расхождений {len(fails)}")
    for f in fails[:10]:
        print("   -", f)
    return len(fails)


def main() -> int:
    ap = argparse.ArgumentParser(description="LuaGuard NG — hardened Lua obfuscator")
    ap.add_argument("input")
    ap.add_argument("-o", "--output", default="output/ng.lua")
    ap.add_argument("--layers", type=int, default=3)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--max-size", type=int, default=1_000_000)
    ap.add_argument("--no-guard", action="store_true", help="disable anti-tamper (for auditing)")
    ap.add_argument("--decoys", type=int, default=2, help="decoy chunks pushed to the loader")
    ap.add_argument("--guard-layers", type=int, default=1,
                    help="how many outer layers carry the full guard stack (default 1)")
    ap.add_argument("--test", action="store_true", help="verify the result in a Lua VM (lupa)")
    args = ap.parse_args()

    src = open(args.input, encoding="utf-8").read()
    g = LuaGuardNG(src, layers=args.layers, seed=args.seed, max_size=args.max_size,
                   guard=not args.no_guard, decoys=args.decoys,
                   guard_layers=args.guard_layers)
    out = g.build()
    for line in g.report:
        print("[*]", line)
    d = os.path.dirname(args.output)
    if d:
        os.makedirs(d, exist_ok=True)
    open(args.output, "w", encoding="utf-8").write(out)
    print(f"[+] wrote {args.output}: {len(out)} bytes ({len(out) / max(1, len(src)):.1f}x)")
    print(f"[i] seed=0x{g.seed:x}")
    if args.test:
        print("[*] self-check ...")
        return 1 if self_check(src, out, g.seed, g.layers) else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
