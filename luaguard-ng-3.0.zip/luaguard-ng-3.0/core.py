#!/usr/bin/env python3
"""
LuaGuard NG — core: randomized ciphers (Python side + exact Lua mirror).

Hard rules (each fixes a v1 defect):
  R1. No bit ops anywhere: only + - * % math.floor  -> runs on Lua 5.1..5.5 / LuaJIT / Luau
      with no bit32/bit and no native bit operators.  (v1 silently no-op'ed without bit32.)
  R2. All Lua temporaries are locals; no globals are created (v1 leaked globals and broke).
  R3. Python encrypt and Lua decrypt are written as the *same* algorithm, mirrored line by
      line, and are cross-verified in a real Lua VM by tests/test_primitives.py.
  R4. Ciphertext feedback: keystream depends on the previous ciphertext byte, so
      "known plaintext -> keystream" does not transfer.
  R5. Every instance is randomized: key, salts, s-boxes, constants, step sizes, mode.
"""

from __future__ import annotations

import math
import random
import struct
from typing import Dict, List, Sequence, Tuple

# =====================================================================
# helpers
# =====================================================================


def perm_from_key(key: Sequence[int], salt: Sequence[int], mode: str, passes: int) -> List[int]:
    """RC4-style KSA producing a permutation of 0..255. Mirrored 1:1 by emit_ksa()."""
    n = len(key)
    s = list(range(256))
    j = 0
    if mode == "forward":
        for i in range(256):
            j = (j + s[i] + key[i % n] + salt[(i * 3) % len(salt)]) & 0xFF
            s[i], s[j] = s[j], s[i]
    elif mode == "reverse":
        for step in range(256):
            i = 255 - step
            j = (j + s[i] + key[(255 - i) % n] + salt[(i * 5 + 1) % len(salt)]) & 0xFF
            s[i], s[j] = s[j], s[i]
    elif mode == "stride":
        stride = (salt[0] % 7) + 3
        for k in range(256):
            i = (k * stride) & 0xFF
            j = (j + s[i] + key[k % n] + salt[(k * 7 + 2) % len(salt)]) & 0xFF
            s[i], s[j] = s[j], s[i]
    else:
        raise ValueError(mode)
    for _ in range(passes):
        for i in range(256):
            j = (j + s[i] + key[(i + j) % n]) & 0xFF
            s[i], s[j] = s[j], s[i]
    return s


def invert_perm(t: Sequence[int]) -> List[int]:
    inv = [0] * 256
    for i, v in enumerate(t):
        inv[v] = i
    return inv


def frame(data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + data


def unframe(data: bytes) -> bytes:
    n = struct.unpack(">I", data[:4])[0]
    return data[4:4 + n]


class Namer:
    """Randomized Lua identifier generator."""

    KEYWORDS = {"and", "break", "do", "else", "elseif", "end", "false", "for", "function",
                "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true",
                "until", "while", "goto"}
    RESERVED = KEYWORDS | {"string", "table", "math", "os", "bit32", "game", "load",
                           "loadstring", "setfenv", "getfenv", "rawget", "rawset", "pcall",
                           "xpcall", "print", "select", "ipairs", "pairs", "type", "typeof",
                           "tostring", "tonumber", "error", "assert", "coroutine", "debug",
                           "require", "task", "Instance", "_G", "_ENV", "self"}
    BODY = "lIioO0aAeEcCsSnNtT"

    def __init__(self, rng: random.Random):
        self.rng = rng
        self.used = set()
        self.styles = ["_%s", "%s", "_%s_", "%s0"]
        rng.shuffle(self.styles)

    def n(self, min_len: int = 6) -> str:
        for _ in range(20000):
            ln = self.rng.randint(min_len, min_len + 5)
            body = "".join(self.rng.choice(self.BODY) for _ in range(ln))
            if self.rng.random() < 0.4:
                pos = self.rng.randint(1, len(body))
                body = body[:pos] + str(self.rng.randint(0, 999)) + body[pos:]
            style = self.rng.choice(self.styles)
            name = style % body
            if name[0].isdigit():
                name = "_" + name
            if name in self.RESERVED or name in self.used:
                continue
            self.used.add(name)
            return name
        raise RuntimeError("namespace exhausted")


def byte_exprs(data: bytes, rng: random.Random) -> List[str]:
    """Hide each key byte inside an arithmetic expression that evaluates EXACTLY to it."""
    out = []
    for b in data:
        k = rng.randint(0, 4)
        if k == 0:
            a = rng.randint(0, 255)
            c = (b - a) % 256
            out.append(f"({a}+{c})%256")
        elif k == 1:
            m = rng.choice([1, 3, 5, 7, 9, 11, 13, 15])
            x = (b * pow(m, -1, 256)) % 256
            out.append(f"({x}*{m})%256")
        elif k == 2:
            m = rng.choice([3, 5, 7, 9, 11, 13])
            c = rng.randint(0, 255)
            x = ((b - c) * pow(m, -1, 256)) % 256
            out.append(f"({x}*{m}+{c})%256")
        elif k == 3:
            a, d = rng.randint(0, 255), rng.randint(0, 255)
            c = (b - a - d) % 256
            out.append(f"({a}+{d}+{c})%256")
        else:
            a = rng.randint(0, 255)
            c = (b - a) % 256
            out.append(f"({c}+{a})%256")
    return out


def emit_ksa(nm: Namer, s_var: str, k_var: str, salt_var: str, mode: str, passes: int,
             reversed_key: bool, nk: int) -> str:
    """Lua mirror of perm_from_key() (0-based table s_var)."""
    i, j, kk, st = nm.n(), nm.n(), nm.n(), nm.n()
    def kidx(e: str) -> str:
        return f"{k_var}[({nk - 1}-({e})%{nk})+1]" if reversed_key else f"{k_var}[({e})%{nk}+1]"
    L = [f"local {i}, {j}, {kk}, {st} ",
         f"for {kk}=0,255 do {s_var}[{kk}]={kk} end {j}=0 "]
    if mode == "forward":
        L.append(f"for {i}=0,255 do {j}=({j}+{s_var}[{i}]+{kidx(i)}+{salt_var}[({i}*3)%#{salt_var}+1])%256 "
                 f"{s_var}[{i}],{s_var}[{j}]={s_var}[{j}],{s_var}[{i}] end ")
    elif mode == "reverse":
        L.append(f"{i}=255 while {i}>=0 do "
                 f"{j}=({j}+{s_var}[{i}]+{kidx(f'(255-{i})')}+{salt_var}[({i}*5+1)%#{salt_var}+1])%256 "
                 f"{s_var}[{i}],{s_var}[{j}]={s_var}[{j}],{s_var}[{i}] {i}={i}-1 end ")
    elif mode == "stride":
        L.append(f"{st}=({salt_var}[1]%7)+3 for {kk}=0,255 do {i}=({kk}*{st})%256 "
                 f"{j}=({j}+{s_var}[{i}]+{kidx(kk)}+{salt_var}[({kk}*7+2)%#{salt_var}+1])%256 "
                 f"{s_var}[{i}],{s_var}[{j}]={s_var}[{j}],{s_var}[{i}] end ")
    else:
        raise ValueError(mode)
    for _ in range(passes):
        L.append(f"for {i}=0,255 do {j}=({j}+{s_var}[{i}]+{kidx(f'({i}+{j})')})%256 "
                 f"{s_var}[{i}],{s_var}[{j}]={s_var}[{j}],{s_var}[{i}] end ")
    return "".join(L)


# =====================================================================
# CIPHER 1 — KSA permutation + substitution + ciphertext feedback ("rc4fb")
# =====================================================================


class CipherRC4FB:
    shape = "rc4fb"

    def __init__(self, rng: random.Random):
        self.rng = rng
        self.key = bytes(rng.randrange(256) for _ in range(rng.randint(24, 32)))
        self.salt = bytes(rng.randrange(256) for _ in range(rng.randint(10, 18)))
        self.mode = rng.choice(["forward", "reverse", "stride"])
        self.passes = rng.randint(1, 2)
        self.S = perm_from_key(self.key, self.salt, self.mode, self.passes)
        self.t_mode = rng.choice(["forward", "reverse", "stride"])
        self.t_passes = rng.randint(0, 1)
        self.T = perm_from_key(self.key[::-1], self.salt, self.t_mode, self.t_passes)
        self.IT = invert_perm(self.T)
        self.step = rng.randint(16, 64)
        self.mix_a = rng.randrange(1, 256) | 1
        self.mix_b = rng.randrange(1, 256)

    def _stream(self, data: bytes, decrypt: bool) -> bytes:
        S, T, IT = self.S[:], self.T, self.IT
        i = j = 0
        fb = self.key[0]
        out = bytearray()
        for pos, x in enumerate(data):
            i = (i + 1) & 0xFF
            j = (j + S[i]) & 0xFF
            S[i], S[j] = S[j], S[i]
            k = S[(S[i] + S[j]) & 0xFF]
            if decrypt:
                p = (IT[x] - k - fb) & 0xFF
                out.append(p)
                fb = (x + i) & 0xFF
            else:
                c = T[(x + k + fb) & 0xFF]
                out.append(c)
                fb = (c + i) & 0xFF
            if (pos + 1) % self.step == 0:
                fb = (fb + self.mix_a * ((pos + 1) & 0xFF) + self.mix_b) & 0xFF
                j = (j + self.mix_b) & 0xFF
        return bytes(out)

    def encrypt(self, data: bytes) -> bytes:
        return self._stream(data, False)

    def decrypt_py(self, data: bytes) -> bytes:
        return self._stream(data, True)

    # ---- Lua mirror ----
    def lua_material(self, nm: Namer) -> Tuple[str, Dict[str, str]]:
        K, SALT = nm.n(), nm.n()
        keys = ",".join(byte_exprs(self.key, self.rng))
        salt = ",".join(byte_exprs(self.salt, self.rng))
        return f"local {K}={{{keys}}} local {SALT}={{{salt}}} ", {"K": K, "SALT": SALT}

    def lua_decode(self, nm: Namer, in_tbl: str, out_tbl: str, env: Dict[str, str]) -> str:
        K, SALT = env["K"], env["SALT"]
        S, T, INV, fb, kk, x, pos, i, j = (nm.n() for _ in range(9))
        L = [f"local {S}, {T}, {INV}, {fb}, {kk}, {x}, {pos}, {i}, {j} "
             f"{S}, {T}, {INV} = {{}}, {{}}, {{}} ",
             emit_ksa(nm, S, K, SALT, self.mode, self.passes, False, len(self.key)),
             emit_ksa(nm, T, K, SALT, self.t_mode, self.t_passes, True, len(self.key)),
             f"for {kk}=0,255 do {INV}[{T}[{kk}]]={kk} end ",
             f"{fb}={K}[1] {i}=0 {j}=0 {out_tbl}={{}} ",
             f"for {pos}=1,#{in_tbl} do {x}={in_tbl}[{pos}] "
             f"{i}=({i}+1)%256 {j}=({j}+{S}[{i}])%256 {S}[{i}],{S}[{j}]={S}[{j}],{S}[{i}] "
             f"{kk}={S}[({S}[{i}]+{S}[{j}])%256] "
             f"{out_tbl}[{pos}]=({INV}[{x}]-{kk}-{fb})%256 "
             f"{fb}=({x}+{i})%256 "
             f"if {pos}%{self.step}==0 then {fb}=({fb}+{self.mix_a}*({pos}%256)+{self.mix_b})%256 "
             f"{j}=({j}+{self.mix_b})%256 end end "]
        return "".join(L)


# =====================================================================
# CIPHER 2 — 16-byte ARS block cipher, counter mode ("ars16")
# =====================================================================


class CipherARS16:
    shape = "ars16"

    def __init__(self, rng: random.Random):
        self.rng = rng
        self.key = bytes(rng.randrange(256) for _ in range(32))
        self.salt = bytes(rng.randrange(256) for _ in range(16))
        self.S = perm_from_key(self.key, self.salt, rng.choice(["forward", "stride"]), rng.randint(1, 2))
        self.rounds = rng.randint(3, 5)
        perm = list(range(16))
        rng.shuffle(perm)
        self.pperm = perm
        self.rk = [[rng.randrange(256) for _ in range(16)] for _ in range(self.rounds)]
        self.nonce = [rng.randrange(256) for _ in range(8)]
        self.mul = rng.choice([3, 5, 7, 11])
        self.add = rng.randrange(1, 256)

    def _ctr(self, b: int) -> List[int]:
        return self.nonce + [math.floor(b / 256) % 256, b % 256, (b * self.mul) % 256,
                             (b * 4 + self.add) % 256, (b + 49) % 256, (b * 3 + 17) % 256,
                             (b + 165) % 256, (b * 11 + 3) % 256]

    def _block(self, blk: List[int]) -> List[int]:
        x = blk[:]
        for r in range(self.rounds):
            rk = self.rk[r]
            x = [self.S[(x[i] + rk[i]) & 0xFF] for i in range(16)]
            xp = [x[self.pperm[i]] for i in range(16)]
            x = [(xp[i] + xp[(i + 1) % 16] + i) & 0xFF for i in range(16)]
        return x

    def _keystream(self, nblocks: int) -> bytes:
        out = bytearray()
        for b in range(nblocks):
            out.extend(bytes(self._block(self._ctr(b))))
        return bytes(out)

    def encrypt(self, data: bytes) -> bytes:
        fr = data
        if len(fr) % 16:
            fr += bytes(16 - len(fr) % 16)
        ks = self._keystream(len(fr) // 16)
        return bytes((fr[i] + ks[i]) & 0xFF for i in range(len(fr)))

    def decrypt_py(self, data: bytes) -> bytes:
        ks = self._keystream(len(data) // 16)
        return bytes((data[i] - ks[i]) & 0xFF for i in range(len(data)))

    # ---- Lua mirror ----
    def lua_material(self, nm: Namer) -> Tuple[str, Dict[str, str]]:
        S, RK, PP, NN = nm.n(), nm.n(), nm.n(), nm.n()
        rk = "{" + ",".join("{" + ",".join(str(v) for v in row) + "}" for row in self.rk) + "}"
        pp = "{" + ",".join(str(v + 1) for v in self.pperm) + "}"
        nn = "{" + ",".join(str(v) for v in self.nonce) + "}"
        code = (f"local {S}={{{','.join(str(v) for v in self.S)}}} local {RK}={rk} "
                f"local {PP}={pp} local {NN}={nn} ")
        return code, {"S": S, "RK": RK, "PP": PP, "NN": NN}

    def lua_decode(self, nm: Namer, in_tbl: str, out_tbl: str, env: Dict[str, str]) -> str:
        S, RK, PP, NN = env["S"], env["RK"], env["PP"], env["NN"]
        i, r, blk, x, jb, nb = (nm.n() for _ in range(6))
        L = [f"local {i}, {r}, {blk}, {x}, {jb}, {nb} {out_tbl}={{}} ",
             f"{nb}=math.floor(#{in_tbl}/16) ",
             f"for {jb}=0,{nb}-1 do "
             f"{blk}={{}} for {i}=1,8 do {blk}[{i}]={NN}[{i}] end "
             f"{blk}[9]=math.floor({jb}/256)%256 {blk}[10]={jb}%256 {blk}[11]=({jb}*{self.mul})%256 "
             f"{blk}[12]=({jb}*4+{self.add})%256 {blk}[13]=({jb}+49)%256 {blk}[14]=({jb}*3+17)%256 "
             f"{blk}[15]=({jb}+165)%256 {blk}[16]=({jb}*11+3)%256 ",
             f"for {r}=1,{self.rounds} do {x}={{}} "
             f"for {i}=1,16 do {x}[{i}]={S}[({blk}[{i}]+{RK}[{r}][{i}])%256+1] end "
             f"for {i}=1,16 do {blk}[{i}]=({x}[{PP}[{i}]]+{x}[{PP}[{i}%16+1]]+{i}-1)%256 end end ",
             f"for {i}=1,16 do {out_tbl}[{jb}*16+{i}]=({in_tbl}[{jb}*16+{i}]-{blk}[{i}])%256 end end "]
        return "".join(L)


# =====================================================================
# CIPHER 3 — two 16-bit LCGs + substitution + feedback ("duallcg")
# =====================================================================


class CipherDualLCG:
    shape = "duallcg"

    def __init__(self, rng: random.Random):
        self.rng = rng
        self.key = bytes(rng.randrange(256) for _ in range(16))
        self.salt = bytes(rng.randrange(256) for _ in range(12))
        self.T = perm_from_key(self.key, self.salt, rng.choice(["forward", "reverse", "stride"]),
                               rng.randint(1, 2))
        self.a1 = rng.choice([25173, 20077, 16838, 17325, 31145, 20321])
        self.c1 = rng.randrange(1, 65536)
        self.a2 = rng.choice([7253, 11039, 17681, 5213, 29873, 12547])
        self.c2 = rng.randrange(1, 65536)
        self.s1 = rng.randrange(1, 65536)
        self.s2 = rng.randrange(1, 65536)
        self.jit = rng.randrange(1, 256) | 1
        self.posmul = rng.choice([1, 3, 5, 7])

    def _stream(self, data: bytes, decrypt: bool) -> bytes:
        s1, s2 = self.s1, self.s2
        prev = self.key[0]
        out = bytearray()
        for pos, x in enumerate(data):
            s1 = (s1 * self.a1 + self.c1 + prev * self.jit) % 65536
            s2 = (s2 * self.a2 + self.c2 + (pos * self.posmul) % 256) % 65536
            k = self.T[((s1 // 256) + s2) % 256]
            if decrypt:
                out.append((x - k - (pos & 0xFF)) & 0xFF)
                prev = x
            else:
                c = (x + k + (pos & 0xFF)) & 0xFF
                out.append(c)
                prev = c
        return bytes(out)

    def encrypt(self, data: bytes) -> bytes:
        return self._stream(data, False)

    def decrypt_py(self, data: bytes) -> bytes:
        return self._stream(data, True)

    # ---- Lua mirror ----
    def lua_material(self, nm: Namer) -> Tuple[str, Dict[str, str]]:
        T = nm.n()
        return f"local {T}={{{','.join(str(v) for v in self.T)}}} ", {"T": T}

    def lua_decode(self, nm: Namer, in_tbl: str, out_tbl: str, env: Dict[str, str]) -> str:
        T = env["T"]
        s1, s2, prev, k, pos, c, o = (nm.n() for _ in range(7))
        return (f"local {s1}, {s2}, {prev}, {k}, {pos}, {c}, {o} "
                f"{s1}={self.s1} {s2}={self.s2} {prev}={self.key[0]} {out_tbl}={{}} "
                f"for {pos}=0,#{in_tbl}-1 do {c}={in_tbl}[{pos}+1] "
                f"{s1}=({s1}*{self.a1}+{self.c1}+{prev}*{self.jit})%65536 "
                f"{s2}=({s2}*{self.a2}+{self.c2}+{pos}*{self.posmul}%256)%65536 "
                f"{k}={T}[(math.floor({s1}/256)+{s2}%256)%256+1] "
                f"{o}=({c}-{k}-{pos}%256)%256 {out_tbl}[{pos}+1]={o} {prev}={c} end ")


# =====================================================================
# CIPHER 4 — byte-oriented SPN with ciphertext feedback ("spn8")
#   state (a,b) -> S-box layers -> permutation substitution of the data byte.
#   Everything is modular byte arithmetic, so it runs on Lua 5.1 without any
#   bit library, and decryption is the exact inverse pipeline.
# =====================================================================


class CipherSPN8:
    shape = "spn8"

    def __init__(self, rng: random.Random):
        self.rng = rng
        self.key = bytes(rng.randrange(256) for _ in range(rng.randint(16, 26)))
        self.salt = bytes(rng.randrange(256) for _ in range(rng.randint(8, 16)))
        self.S = perm_from_key(self.key, self.salt, rng.choice(["forward", "reverse", "stride"]),
                               rng.randint(1, 2))
        self.T = list(range(256))
        rng.shuffle(self.T)
        self.IT = invert_perm(self.T)
        self.R = [rng.randrange(256) for _ in range(rng.randint(6, 12))]
        self.mul = rng.choice([3, 5, 7, 9, 11, 13, 15])
        self.tweak = rng.randrange(0, 256)
        self.order = rng.choice(["ab", "ba"])

    def _stream(self, data: bytes, decrypt: bool) -> bytes:
        key, S, T, IT, R = self.key, self.S, self.T, self.IT, self.R
        nk, nr = len(key), len(R)
        a, b = key[0], key[1 % nk]
        fb = self.salt[0]
        out = bytearray()
        for pos, x in enumerate(data):
            a = S[(a + key[pos % nk] + fb) & 0xFF]
            b = S[(b + a + R[pos % nr] + self.tweak) & 0xFF]
            k = (a + b * self.mul) & 0xFF if self.order == "ab" else (b + a * self.mul) & 0xFF
            if decrypt:
                out.append((IT[x] - k) & 0xFF)
                fb = (x + pos) & 0xFF
            else:
                c = T[(x + k) & 0xFF]
                out.append(c)
                fb = (c + pos) & 0xFF
        return bytes(out)

    def encrypt(self, data: bytes) -> bytes:
        return self._stream(data, False)

    def decrypt_py(self, data: bytes) -> bytes:
        return self._stream(data, True)

    # ---- Lua mirror ----
    def lua_material(self, nm: Namer) -> Tuple[str, Dict[str, str]]:
        K, SALT, S, T, IT, R = (nm.n() for _ in range(6))
        keys = ",".join(byte_exprs(self.key, self.rng))
        salt = ",".join(byte_exprs(self.salt, self.rng))
        code = (f"local {K}={{{keys}}} local {SALT}={{{salt}}} "
                f"local {S}={{{','.join(str(v) for v in self.S)}}} "
                f"local {T}={{{','.join(str(v) for v in self.T)}}} "
                f"local {IT}={{{','.join(str(v) for v in self.IT)}}} "
                f"local {R}={{{','.join(str(v) for v in self.R)}}} ")
        return code, {"K": K, "SALT": SALT, "S": S, "T": T, "IT": IT, "R": R}

    def lua_decode(self, nm: Namer, in_tbl: str, out_tbl: str, env: Dict[str, str]) -> str:
        K, SALT, S, T, IT, R = (env[x] for x in ("K", "SALT", "S", "T", "IT", "R"))
        a, b, fb, k, pos, x, o = (nm.n() for _ in range(7))
        kexpr = (f"({a}+{b}*{self.mul})" if self.order == "ab" else f"({b}+{a}*{self.mul})")
        return (f"local {a}, {b}, {fb}, {k}, {pos}, {x}, {o} "
                f"{a}={K}[1] {b}={K}[2] {fb}={SALT}[1] {out_tbl}={{}} "
                f"for {pos}=1,#{in_tbl} do {x}={in_tbl}[{pos}] "
                f"{a}={S}[({a}+{K}[({pos}-1)%#{K}+1]+{fb})%256+1] "
                f"{b}={S}[({b}+{a}+{R}[({pos}-1)%#{R}+1]+{self.tweak})%256+1] "
                f"{k}={kexpr}%256 "
                f"{o}=({IT}[{x}+1]-{k})%256 {out_tbl}[{pos}]={o} "
                f"{fb}=({x}+{pos}-1)%256 end ")


# =====================================================================
# CIPHER 5 — 16-bit Feistel keystream with feedback ("feistel2")
# =====================================================================


class CipherFeistel2:
    shape = "feistel2"

    def __init__(self, rng: random.Random):
        self.rng = rng
        self.key = bytes(rng.randrange(256) for _ in range(rng.randint(12, 24)))
        self.salt = bytes(rng.randrange(256) for _ in range(rng.randint(8, 14)))
        self.S = perm_from_key(self.key, self.salt, rng.choice(["forward", "reverse", "stride"]),
                               rng.randint(1, 2))
        self.T = list(range(256))
        rng.shuffle(self.T)
        self.IT = invert_perm(self.T)
        self.rounds = rng.randint(4, 9)
        self.rk = [[rng.randrange(256), rng.randrange(256)] for _ in range(self.rounds)]
        self.jit = rng.randrange(1, 256)
        self.extra = rng.randrange(0, 256)

    def _stream(self, data: bytes, decrypt: bool) -> bytes:
        key, S, T, IT = self.key, self.S, self.T, self.IT
        nk = len(key)
        left, right = key[0], key[1 % nk]
        fb = self.salt[0]
        out = bytearray()
        for pos, x in enumerate(data):
            left = (left + key[pos % nk] + fb) & 0xFF
            for r in range(self.rounds):
                f = S[(right + self.rk[r][0] + pos) & 0xFF]
                left, right = right, (left + f + self.rk[r][1]) & 0xFF
            k = (left + right + pos * self.jit + self.extra) & 0xFF
            if decrypt:
                out.append((IT[x] - k) & 0xFF)
                fb = (x + pos) & 0xFF
            else:
                c = T[(x + k) & 0xFF]
                out.append(c)
                fb = (c + pos) & 0xFF
        return bytes(out)

    def encrypt(self, data: bytes) -> bytes:
        return self._stream(data, False)

    def decrypt_py(self, data: bytes) -> bytes:
        return self._stream(data, True)

    # ---- Lua mirror ----
    def lua_material(self, nm: Namer) -> Tuple[str, Dict[str, str]]:
        K, SALT, S, T, IT, RK = (nm.n() for _ in range(6))
        keys = ",".join(byte_exprs(self.key, self.rng))
        salt = ",".join(byte_exprs(self.salt, self.rng))
        rk = "{" + ",".join("{%d,%d}" % (row[0], row[1]) for row in self.rk) + "}"
        code = (f"local {K}={{{keys}}} local {SALT}={{{salt}}} "
                f"local {S}={{{','.join(str(v) for v in self.S)}}} "
                f"local {T}={{{','.join(str(v) for v in self.T)}}} "
                f"local {IT}={{{','.join(str(v) for v in self.IT)}}} "
                f"local {RK}={rk} ")
        return code, {"K": K, "SALT": SALT, "S": S, "T": T, "IT": IT, "RK": RK}

    def lua_decode(self, nm: Namer, in_tbl: str, out_tbl: str, env: Dict[str, str]) -> str:
        K, SALT, S, T, IT, RK = (env[x] for x in ("K", "SALT", "S", "T", "IT", "RK"))
        left, right, fb, k, pos, x, r, tmp = (nm.n() for _ in range(8))
        return (f"local {left}, {right}, {fb}, {k}, {pos}, {x}, {r}, {tmp} "
                f"{left}={K}[1] {right}={K}[2] {fb}={SALT}[1] {out_tbl}={{}} "
                f"for {pos}=1,#{in_tbl} do {x}={in_tbl}[{pos}] "
                f"{left}=({left}+{K}[({pos}-1)%#{K}+1]+{fb})%256 "
                f"for {r}=1,{self.rounds} do "
                f"{tmp}={S}[({right}+{RK}[{r}][1]+{pos}-1)%256+1] "
                f"{left}, {right} = {right}, ({left}+{tmp}+{RK}[{r}][2])%256 end "
                f"{k}=({left}+{right}+({pos}-1)*{self.jit}+{self.extra})%256 "
                f"{out_tbl}[{pos}]=({IT}[{x}+1]-{k})%256 "
                f"{fb}=({x}+{pos}-1)%256 end ")


CIPHERS = [CipherRC4FB, CipherARS16, CipherDualLCG, CipherSPN8, CipherFeistel2]
CIPHER_BY_SHAPE = {c.shape: c for c in CIPHERS}

